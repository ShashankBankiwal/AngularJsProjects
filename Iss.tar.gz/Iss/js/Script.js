var app=angular.module('Myapp', ['ngMaterial']);

app.filter('splitSchoolYear', function() {
	return function(number) {
		return number + "/" + (number + 1).toString().substring(2);
	};
});

app.run(function($rootScope) 
		{
			$rootScope.showAlert = function(msg, err)
		  	{
				if(err == "error")
		  			$("#msgHeader").css( "background-color", "#cc0000");

		  		$('#MessageBox').modal({
		  			show: true,
		  		});

				$("#modal-title-area").html("Alert");

		  		$("#modal-body-MessageBox").empty();
		  		$("#modal-body-MessageBox").html(msg);
		  	};
		  	
		  	$rootScope.confirmationBox = function()
		  	{
		  		$('#approvelStatusConfirmation').modal({
		  			show: true,
		  		});
		  	};
		});
	app.controller('Ctrl', function($scope,$timeout){
		$scope.doc = true;
	$scope.ratingsData = angular.copy(data[0]);
	$scope.dataOFPreviousMonth = angular.copy(data[0]);
    $scope.selectedIssYears = new Date().getFullYear();
    $scope.selectedMonth = ""; 	
    $scope.selectedMonths = ""; 
	$scope.temp=[];
	$scope.fetchedFormData = [];
    $scope.schoolKey = "";
    $scope.monthKey = "";
    $scope.ISSSchoolData={};
    $scope.ISSFormData={};
    $scope.monthData=[];
    $scope.schoolKey ="";
    $scope.UserView = true;
    $scope.selectedSchool = "";
    
	var spaceKey = parent.$.jStorage.get("spacekey").trim();
	var authToken = parent.$.jStorage.get("authToken").trim();
	
    var year = new Date().getFullYear();
    var range = [];
    var rangedate= year-5;
    for (var i = 0; i <= 10; i++) {
        range.push(rangedate + i);
    }
    $scope.years = range;
    
    var parameters = location.search.substring(1).split("?");
	var temp = parameters[0].split("=");
	var l = unescape(temp[2]);
	var obj = JSON.parse(l);
	$scope.school = [];
	$scope.school = angular.copy(obj.customproperties);
	
	$scope.getSchoolKey = function(){
		$scope.userType = "";
		
		for(var i=0 in $scope.school){
			if($scope.school[i].key == "ISS_USERTYPE"){
				$scope.userType = $scope.school[i].value;
			}
		} var timeout = null;
		
		if($scope.userType == "Admin"){
			$scope.ISSSchoolData.issMonth.monthKey = $scope.selectedMonths.monthKey;
			$scope.getISSSchoolData();
		}else{
			$scope.UserView = false;
			for(var i=0 in $scope.school){
				if($scope.school[i].key == "School_Key"){
					$scope.schoolKey = $scope.school[i].value;
				}
			}
			
			$scope.ISSFormData.schoolYear=$scope.selectedIssYears+"";
			   $scope.ISSFormData.schoolKey=$scope.schoolKey-"";
			   $scope.ISSFormData.monthOrder=$scope.selectedMonths.monthOrder-"";
			  //$scope.getISS$watchFormData();
			  $scope.getISSFormData();
		}
		   
	};
	
	
    $scope.changeSchoolYear = function(res){
    	$scope.selectedIssYears = res;
    	$scope.getISSMonthData();
    };
    
    
   	$scope.getMonthData = function(res){
		$scope.$apply(function(){
 		$scope.monthData = res.issResponse.issMonthList;
   		$scope.monthDatas = res.issResponse.issMonthList;
		$scope.selectedMonth =  $scope.monthData[0].monthOrder;;
		$scope.selectedMonths =$scope.monthDatas[0];
		 $scope.ISSFormData.schoolYear=$scope.selectedIssYears+"";
		$scope.ISSFormData.monthOrder=$scope.selectedMonths.monthOrder-"";
		});
		$scope.getSchoolKey();
	};
	
	$scope.changeValues = function(res){
		$scope.selectedMonth = res;
		for(key in  $scope.monthData ){
			if($scope.monthData[key].monthOrder ==res ){
				$scope.selectedMonths =  $scope.monthData[key];
		        $scope.ISSFormData.monthOrder=$scope.selectedMonths.monthOrder-"";
			}
		}
		
		$scope.getISSFormData();
	};
	
	$scope.schoolList = function(res){
		console.log(res);
		$scope.schoolLIstArr = [];
		for(key in res.issResponse.issSchoolList){
			$scope.schoolLIstArr.push(res.issResponse.issSchoolList[key]);
		}
		$scope.changeSchoolName($scope.schoolLIstArr[0]);
	};
	
	$scope.changeSchoolName = function(res){
		$scope.selectedSchool = res.schoolName;
		$scope.schoolKey =res.schoolKey;
		 $scope.ISSFormData.schoolYear=$scope.selectedIssYears+"";
		   $scope.ISSFormData.schoolKey=$scope.schoolKey-"";
		   $scope.ISSFormData.monthOrder=$scope.selectedMonths.monthOrder-"";
		  $scope.getISSFormData();
	};
    
    $scope.getData = function(res){ 
    	if(res.issResponse.formData !== undefined ){
    		var a = JSON.parse(res.issResponse.formData);  
    		$scope.fetchedFormData = [];
    		for(var item in a.formDataList.fieldValues){
    			if(a.formDataList.fieldValues[item].formId && a.formDataList.fieldValues[item].formId > 0)
    				$scope.fetchedFormData.push(a.formDataList.fieldValues[item]);
    		}
    		
    		for(key in a.formDataList.fieldValues){
    			if(a.formDataList.fieldValues[key].fieldKey == "ISS_ACAD_RATING"){
    			$scope.ratingsData.ISS_ACAD_RATING =a.formDataList.fieldValues[key].fieldValue;
    			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_ACAD_TEXT"){
    			$scope.ratingsData.ISS_ACAD_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			}else if (a.formDataList.fieldValues[key].fieldKey == "ISS_AUTHOR"){
    			$scope.ratingsData.ISS_AUTHOR =a.formDataList.fieldValues[key].fieldValue;
    			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_CANDO"){
    			$scope.ratingsData.ISS_CANDO =a.formDataList.fieldValues[key].fieldValue;
    			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_CANDO"){
    			$scope.ratingsData.ISS_AUTHOR =a.formDataList.fieldValues[key].fieldValue;
    			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_REPORT_TYPE"){
    			$scope.ratingsData.ISS_REPORT_TYPE =a.formDataList.fieldValues[key].fieldValue;
    			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_REVIEWER"){
    			$scope.ratingsData.ISS_REVIEWER =a.formDataList.fieldValues[key].fieldValue;
    			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_FIN_RATING"){
    			$scope.ratingsData.ISS_FIN_RATING =a.formDataList.fieldValues[key].fieldValue;
    			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_FIN_TEXT"){
    			$scope.ratingsData.ISS_FIN_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_STAFF_RATING"){
    			$scope.ratingsData.ISS_STAFF_RATING =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_STAFF_TEXT"){
    			$scope.ratingsData.ISS_STAFF_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_SISSUE_RATING"){
    			$scope.ratingsData.ISS_SISSUE_RATING =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_SISSUE_TEXT"){
    			$scope.ratingsData.ISS_SISSUE_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_LRISSUE_RATING"){
    			$scope.ratingsData.ISS_LRISSUE_RATING =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_LRISSUE_TEXT"){
    			$scope.ratingsData.ISS_LRISSUE_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_PCISSUE_RATING"){
    			$scope.ratingsData.ISS_PCISSUE_RATING =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_PCISSUE_TEXT"){
    			$scope.ratingsData.ISS_PCISSUE_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_EFACTOR_RATING"){
    			$scope.ratingsData.ISS_EFACTOR_RATING =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_EFACTOR_TEXT"){
    			$scope.ratingsData.ISS_EFACTOR_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			}  else if(a.formDataList.fieldValues[key].fieldKey == "ISS_SPONSOR_RATING"){
    			$scope.ratingsData.ISS_SPONSOR_RATING =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_SPONSOR_TEXT"){
    			$scope.ratingsData.ISS_SPONSOR_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			}  else if(a.formDataList.fieldValues[key].fieldKey == "ISS_RESOURCES_RATING"){
    			$scope.ratingsData.ISS_RESOURCES_RATING =a.formDataList.fieldValues[key].fieldValue;
    			}  else if(a.formDataList.fieldValues[key].fieldKey == "ISS_RESOURCES_TEXT"){
    			$scope.ratingsData.ISS_RESOURCES_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			}  else if(a.formDataList.fieldValues[key].fieldKey == "ISS_PROGRESS_RATING"){
    			$scope.ratingsData.ISS_PROGRESS_RATING =a.formDataList.fieldValues[key].fieldValue;
    			}   else if(a.formDataList.fieldValues[key].fieldKey == "ISS_PROGRESS_TEXT"){
    			$scope.ratingsData.ISS_PROGRESS_TEXT =a.formDataList.fieldValues[key].fieldValue;
    			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_CRUCIAL"){
    			$scope.ratingsData.ISS_CRUCIAL =a.formDataList.fieldValues[key].fieldValue;
    			}
    		}
    		$scope.FormDataOfPreviousMonth = $scope.ISSFormData;
    		$scope.FormDataOfPreviousMonth.monthOrder = $scope.selectedMonths.monthOrder-1;
    		 $scope.getISSFormDatas();
    		}else{
    			$scope.ratingsData = angular.copy(data[0]);
    			$scope.fetchedFormData = [];
    			$scope.FormDataOfPreviousMonth = $scope.ISSFormData;
    			$scope.FormDataOfPreviousMonth = $scope.ISSFormData;
				$scope.FormDataOfPreviousMonth.monthOrder = $scope.selectedMonths.monthOrder-1;
        		 $scope.getISSFormDatas();
    		}
	};
    	
	$scope.getDataOFPreviousMonth = function(res){
		$scope.$apply(function(){
		if(res.issResponse.formData !== undefined ){
        		var a = JSON.parse(res.issResponse.formData);  
        		for(key in a.formDataList.fieldValues){
        			if(a.formDataList.fieldValues[key].fieldKey == "ISS_ACAD_RATING"){
        			$scope.dataOFPreviousMonth.ISS_ACAD_RATING =a.formDataList.fieldValues[key].fieldValue;
        			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_ACAD_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_ACAD_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			}else if (a.formDataList.fieldValues[key].fieldKey == "ISS_AUTHOR"){
        			$scope.dataOFPreviousMonth.ISS_AUTHOR =a.formDataList.fieldValues[key].fieldValue;
        			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_CANDO"){
        			$scope.dataOFPreviousMonth.ISS_CANDO =a.formDataList.fieldValues[key].fieldValue;
        			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_CANDO"){
        			$scope.dataOFPreviousMonth.ISS_AUTHOR =a.formDataList.fieldValues[key].fieldValue;
        			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_REPORT_TYPE"){
        			$scope.dataOFPreviousMonth.ISS_REPORT_TYPE =a.formDataList.fieldValues[key].fieldValue;
        			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_REVIEWER"){
        			$scope.dataOFPreviousMonth.ISS_REVIEWER =a.formDataList.fieldValues[key].fieldValue;
        			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_FIN_RATING"){
        			$scope.dataOFPreviousMonth.ISS_FIN_RATING =a.formDataList.fieldValues[key].fieldValue;
        			}else if(a.formDataList.fieldValues[key].fieldKey == "ISS_FIN_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_FIN_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_STAFF_RATING"){
        			$scope.dataOFPreviousMonth.ISS_STAFF_RATING =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_STAFF_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_STAFF_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_SISSUE_RATING"){
        			$scope.dataOFPreviousMonth.ISS_SISSUE_RATING =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_SISSUE_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_SISSUE_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_LRISSUE_RATING"){
        			$scope.dataOFPreviousMonth.ISS_LRISSUE_RATING =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_LRISSUE_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_LRISSUE_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_PCISSUE_RATING"){
        			$scope.dataOFPreviousMonth.ISS_PCISSUE_RATING =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_PCISSUE_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_PCISSUE_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_EFACTOR_RATING"){
        			$scope.dataOFPreviousMonth.ISS_EFACTOR_RATING =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_EFACTOR_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_EFACTOR_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			}  else if(a.formDataList.fieldValues[key].fieldKey == "ISS_SPONSOR_RATING"){
        			$scope.dataOFPreviousMonth.ISS_SPONSOR_RATING =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_SPONSOR_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_SPONSOR_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			}  else if(a.formDataList.fieldValues[key].fieldKey == "ISS_RESOURCES_RATING"){
        			$scope.dataOFPreviousMonth.ISS_RESOURCES_RATING =a.formDataList.fieldValues[key].fieldValue;
        			}  else if(a.formDataList.fieldValues[key].fieldKey == "ISS_RESOURCES_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_RESOURCES_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			}  else if(a.formDataList.fieldValues[key].fieldKey == "ISS_PROGRESS_RATING"){
        			$scope.dataOFPreviousMonth.ISS_PROGRESS_RATING =a.formDataList.fieldValues[key].fieldValue;
        			}   else if(a.formDataList.fieldValues[key].fieldKey == "ISS_PROGRESS_TEXT"){
        			$scope.dataOFPreviousMonth.ISS_PROGRESS_TEXT =a.formDataList.fieldValues[key].fieldValue;
        			} else if(a.formDataList.fieldValues[key].fieldKey == "ISS_CRUCIAL"){
        			$scope.dataOFPreviousMonth.ISS_CRUCIAL =a.formDataList.fieldValues[key].fieldValue;
        			}
        		};
    	}else {
    		$scope.dataOFPreviousMonth = angular.copy(data[0]);
    	}
		});
	};
	
	$scope.clear = function(){
		$scope.$apply(function(){
		$scope.ratingsData = angular.copy(data[0]);
		$scope.dataOFPreviousMonth = angular.copy(data[0]);
		});
	};
  
    $scope.savedata = function(){
    	$scope.temp = [];
    	var issSchool= {
    			"schoolKey": $scope.schoolKey
    	};
    	var issMonth = {
    			"monthKey":$scope.selectedMonths.monthKey-"" 
    	};
    	var commonObj={};
    	commonObj.formId=null;
    	commonObj.schoolYear=$scope.selectedIssYears;
    	commonObj.issSchool=issSchool;
    	commonObj.issMonth =issMonth;
    	//commonObj.message=$scope.messaging;
    
    	var keys = Object.keys($scope.ratingsData);
    	var values = Object.values($scope.ratingsData);
    	for (var k = 1; k < keys.length; k++) {
		if(keys[k] !== "schoolYear") {
			if(values[k]!="" ){
				var tempObj= angular.copy(commonObj);
				tempObj.fieldKey = keys[k];
				tempObj.formId = getFormId(tempObj.fieldKey);
				tempfieldValue = values[k].replace(/\n/g,"\\n");
				tempObj.fieldValue = tempfieldValue.replace(/"/g,'\\"');
				tempObj.lastUpdatedTime ="";
				tempObj.lastUpdatedBy ="";
				//console.log($scope.messaging);
				$scope.temp.push(tempObj);
			}
		}
    	}
    	$scope.saveIssData ();
    };
			
			$scope.saveIssData = function(res) {
				var Obj = {
					"spaceKey" : spaceKey,
					"token" : authToken,
					"jsonString" : JSON
							.stringify($scope.temp)
				};
				ajaxCall(
						Obj,
						urls[0]["SaveISSFormData"],
						function(response) {

							if (response !== undefined) {
								if (response.issResponse.success) {
									$scope.ISSFormData.monthOrder = $scope.selectedMonths.monthOrder;
									$scope.getISSFormData();
									$scope.showAlert(
											"Data Saved Successfully",
											"noError");
								} else {
									$scope.showAlert(response.issResponse.errorMessage,"error");
								}
							}
						});
		};

		
	function getFormId(key)
	{
		var id=null;
		if($scope.fetchedFormData)
		{
			for(var item in $scope.fetchedFormData){
				if($scope.fetchedFormData[item].fieldKey == key)
					id = $scope.fetchedFormData[item].formId
			}
		}
		return id;
	};
	
    /*--------------------------********GetISSMonthData********--------------------------------*/

   $scope.getISSMonthData=function(){
	   var Obj = {
				"spaceKey" : spaceKey,
				"token" : authToken,
				"jsonString" : ""
			};
			ajaxCall(
					Obj,
					urls[0]["GetISSMonthData"],
					
					function(response){
						$scope.getMonthData(response);
					});
	  
   };
   
   /*--------------------------********GetISSFormData********--------------------------------*/
   
	   $scope.ISSFormData.schoolYear=$scope.selectedIssYears+"";
	   $scope.ISSFormData.schoolKey=$scope.schoolKey;
	   $scope.ISSFormData.monthOrder=$scope.selectedMonths.monthOrder-"";
   
   $scope.getISSFormData=function(){
	   var Obj = {
				"spaceKey" : spaceKey,
				"token" : authToken,
				"jsonString" : JSON
							   .stringify($scope.ISSFormData)
			};
			ajaxCall(
					Obj,
					urls[0]["GetISSFormData"],
					
					function(response) {
						if(response !== undefined){
							$scope.getData(response);
						}
						
					});
	  
   };
   
   
   $scope.getISSFormDatas=function(){
	   var Obj = {
				"spaceKey" : spaceKey,
				"token" : authToken,
				"jsonString" : JSON
							   .stringify($scope.FormDataOfPreviousMonth)
			};
			ajaxCall(
					Obj,
					urls[0]["GetISSFormData"],
					
					function(response) {
						if(response !== undefined){
							$scope.getDataOFPreviousMonth(response);
						}
						
					});
	  
   };
   
   /*--------------------------********GetISSSchoolData********--------------------------------*/
   var issMonth = {
			"monthKey": $scope.selectedMonths.monthKey-""
		};
   $scope.ISSSchoolData.schoolYear=$scope.selectedIssYears;
   $scope.ISSSchoolData.issMonth= issMonth;
   $scope.getISSSchoolData=function(){
	   var Obj = {
				"spaceKey" : spaceKey,
				"token" : authToken,
				"jsonString" : JSON.stringify($scope.ISSSchoolData)
			};
			ajaxCall(
					Obj,
					urls[0]["GetISSAllSchoolData"],
					function(response) {
						$scope.schoolList(response);
					});
   };
   
  	
	$scope.showAlert = function(msg, err, header) {
		$("#msgHeader").css("background-color",
				"rgb(83, 84, 84)");
		if (err == "error")
			$("#msgHeader").css("background-color",
					"#cc0000");

		$('#MessageBox1').modal({
			show : true,
		});
		$("#modal-title-area").html("Information");
		if (header != null && header != undefined)
			$("#modal-title-area").html(header);

		$("#modal-body-MessageBox").empty();
		$("#modal-body-MessageBox").html(msg);
	};
  	
  	$scope.noCallBackMethod = function() {
        
	};
	

    
   function ajaxCall(ajaxObj, serviceId, callback, msgNo) {
		$.ajax({
					type : "POST",
					url : serviceId,
					data : ajaxObj,
					traditional : true,
					crossDomain : true,
					success : (function(response, status, headers, config) {
						for ( var propName in response) {
							if (response[propName].sucess == false
									&& response[propName].errorMessage == "Invalid Token/Request") {
								$scope.showAlert(
										"Session Expired. Please re-login.",
										"error");
								return;
							}
							break;
						}
						callback(response, msgNo);
					}),
					error : function(data, status) {
						$scope.showAlert("Error  " + status);
					}
				});
	}
   
   $scope.messaging="";
	var timeout=null;
	$scope.savelocally = function(){
		if($scope.messaging.$valid){
			alert("Your Data has been saved");
		}
	}
	$scope.savedData=function(newVal,oldVal){
		alert(newVal);
		alert(oldVal);
	    	if(newValue!=null||newVal!=oldVal){
	    		if(timeout){
	    			$timeout.cancel(timeout);
	    		}
	    		timeout=$timeout($scope.savelocally,1000);
	    	}
	}
	$scope.$watch('$scope.messaging',$scope.savedData);
	$scope.getISSMonthData();
   
  	 
});
/*app.controller("ChildController",function($scope,$timeout){
	$scope.messaging="";
	var timeout=null;
	var savelocally = function(){
		if($scope.messaging.$valid){
			alert("Your Data has been saved");
		}
	}
	var savedData=function(newVal,oldVal){
		alert(newVal);
		alert(oldVal);
	    	if(newValue!=null||newVal!=oldVal){
	    		if(timeout){
	    			$timeout.cancel(timeout);
	    		}
	    		timeout=$timeout(savelocally,1000);
	    	}
	}
	$scope.$watch('$scope.messaging',savedData);
	
});	*/