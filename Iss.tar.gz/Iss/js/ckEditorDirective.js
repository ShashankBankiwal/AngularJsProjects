app.directive('ckEditor', [function () {
		return {
			require: '?ngModel',
			restrict: 'C',
			priority: 1,
			link: function(scope, elm, attr, ngModel) 
			{
				var ck = CKEDITOR.replace(elm[0],
						{
					toolbar : [
					           {
					        	   name : 'basicstyles',
					        	   groups : [ 'basicstyles', 'cleanup' ],
					        	   items : [ 'Bold', 'Italic', 'Underline', 'Strike', 
					        	             'Subscript','Superscript', '-', 'RemoveFormat' ]
					           },
					     
					           { 
					        	 name: 'paragraph', 
					        	 groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ], 
					        	 items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-',
					        	          'Blockquote', '-', 'JustifyLeft', 'JustifyCenter',
					        	          'JustifyRight', 'JustifyBlock', '-'] 
					           },
					           
					           { 
					        	 name: 'colors', 
					        	 items: [ 'TextColor', 'BGColor' ] 
					           },
					           { 
					        	 name: 'links', 
					        	 items: ['Link', 'Unlink'] 
						       }
					          ],
					           height : '130'
						});

				if (!ngModel) return;

				ck.on('instanceReady', function() {
					
					if(ngModel.$viewValue) {
						
						ck.setData(ngModel.$viewValue);
					}
				});

				function updateModel() 
				{
					if ( ck.getData().length >=0)
						ngModel.$setViewValue(ck.getData());
					/*scope.$apply(function() {
					});*/
				}

				ck.on('change', updateModel);
				ck.on('onLoad', updateModel);
				ck.on('key', updateModel);
				ck.on('pasteState', updateModel); 

				ngModel.$render = function(value) {
					ck.setData(ngModel.$viewValue);
				};
			}
		};
	}]);