var sisModule = angular.module('myapps',['ngMaterial','ngRoute']);

sisModule.config(function($routeProvider) 
		{
			$routeProvider.
				when('/assesment', {
					templateUrl: '../../../../views/edubvz/commonassesment/views/allItems.html',
					controller: 'MyCtrl'
			   }).
			   otherwise({
				   redirectTo: '/assesment'
			   });
		});

sisModule.run(function($rootScope){  
	$rootScope.studentList = [];
	$rootScope.guardianList = [];
	$rootScope.classList=[];
	$rootScope.subjectList=[];
	$rootScope.teacherList = [];
	$rootScope.FormMap = [];
	
	$rootScope.userDetails = {};
	$rootScope.themeDetails = {};
	$rootScope.sdk = {};
   	
   	try {
   		$rootScope.userDetails = BIZVIZ.SDK.getAuthInfo();
   		$rootScope.themeDetails = $.jStorage.get("preferenceObject");/*$rootScope.userDetails.preference.themeID;*/
   		$rootScope.sdk = BIZVIZ.SDK;
   	   	pathforpopHtml = "";
   	} catch(err) {
   		
   		$rootScope.userDetails = parent.BIZVIZ.SDK.getAuthInfo();
   	   	$rootScope.themeDetails = parent.$.jStorage.get("preferenceObject");/*$rootScope.userDetails.preference.themeID;*/
   	   	$rootScope.sdk = parent.BIZVIZ.SDK;
   	   	pathforpopHtml = "popUpTemplete.html";
   	};
   	$rootScope.requireURL = req_url.otms.ipluginService;

    $rootScope.manageTheme = function()	{
  		$("#sisNavbar.navbar-default").css("background-color", $rootScope.themeDetails.navBarBGColor);
  		$('.navbar-default .navbar-nav > li > a,.navbar-default .navbar-nav > li > a > i').css("color",$rootScope.themeDetails.navBarTextAndIconColor);
  		$(".btn-color-theme").css( "background", $rootScope.themeDetails.headerBGColor );
  		$(".btn-color-theme").hover(function(){
  		    $(this).css("background-color", $rootScope.themeDetails.navBarBGColor);
  		    }, function(){
  		    $(this).css("background-color", $rootScope.themeDetails.headerBGColor);
  		});

  		$(".sisIcon").css("color", $rootScope.themeDetails.headerBGColor);
  		$(".sisIcon").hover(function(){
  		    $(this).css("color", $rootScope.themeDetails.navBarBGColor);
  		    }, function(){
  		    $(this).css("color", $rootScope.themeDetails.headerBGColor);
  		});

  		$("thead").css("background", $rootScope.themeDetails.headerBGColor);
  		//$("thead").css("background","rgb(169, 169, 169)");
  		$(".sis-header").css("background", $rootScope.themeDetails.navBarBGColor);
  		$(".thememanage").css("background", $rootScope.themeDetails.navBarBGColor);
  		$(".dropdown-menu.custom-menu").css("background", $rootScope.themeDetails.contextMenuBGColor);
  		$(".dropdown-menu.custom-menu").css("color", $rootScope.themeDetails.contextMenuTextAndIconColor);
  		$(".modal-header").css("background", $rootScope.themeDetails.headerBGColor);
  		$(".modal-title").css("color", $rootScope.themeDetails.headerTextAndIconColor);
  	};
  	
  	$rootScope.getModalTheme = function(element){
  		switch(element){
	  		case "thead":
	  			return {
	  				background: $rootScope.themeDetails.headerBGColor
	  			}
	  		case 'button':
	  			return {
	  				background: $rootScope.themeDetails.headerBGColor
	  			}
	  		case 'header':
	  			return {
  					background: $rootScope.themeDetails.headerBGColor,
  				}
	  		case "sisIcon" :
	  			return {
	  				color: $rootScope.themeDetails.headerBGColor
				}
	  		case "modal-title":
	  			return {
					color: $rootScope.themeDetails.headerTextAndIconColor
				}
	  		}
  			
  	};
  	
  	$rootScope.showNotification= function(msg,err,header){
  		
  	}
  	
  	$rootScope.showAlert = function(msg, err, header) {
  		
  		$("#msgHeader").css( "background-color", $rootScope.themeDetails.headerBGColor);
  		if(err == "error")
  			$("#msgHeader").css( "background-color", "#cc0000");

  		$('#MessageBox').modal({
  			show: true,
  		});

		$("#modal-title-area").html("Instructions");
		if(header != null && header != undefined)
			$("#modal-title-area").html(header);

  		$("#modal-body-MessageBox").empty();
  		$("#modal-body-MessageBox").html(msg);
  		//$timeout(function(){$('#MessageBox').slideUp();},2000);
  		
  		/*$('#MessageBox').delay(2000).slideUp(200, function() {
  			$(this).alert('close');
  		});*/
  	};
});

sisModule.controller('MyCtrl',['$scope','$mdSidenav',function($scope,$mdSidenav){
	 
      	
        
        }]);

sisModule.directive('input', [function() {
    return {
        restrict: 'E',
        require: '?ngModel',
        link: function(scope, element, attrs, ngModel) {
            if (
                   'undefined' !== typeof attrs.type
                && 'number' === attrs.type
                && ngModel
            ) {
                ngModel.$formatters.push(function(modelValue) {
                    return Number(modelValue);
                });

                ngModel.$parsers.push(function(viewValue) {
                    return Number(viewValue);
                });
            }
        }
    }
}]);

sisModule.filter('splitSchoolYear', function() {
	return function(number) {
		return number + "/" + (number + 1).toString().substring(2);
	};
});


sisModule.service("Comparators", function() { 
	  this.year = function(r1, r2) {
	    if(r1.activeStatus === r2.activeStatus) {
	      if (r1.extent === r2.extent) return 0;
	      return r1.extent > r2.extent ? 1 : -1;
	    } else if(!r1.activeStatus || !r2.activeStatus) {
	      return !r1.activeStatus && !r2.activeStatus ? 0 : (!r1.activeStatus ? 1 : -1);
	    }
	    return r1.activeStatus > r2.planYear ? 1 : -1;
	  };
	});

