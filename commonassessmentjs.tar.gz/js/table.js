var assesmentServiceObject = {
	"consumerName":"ASSESSMENT_SERVICE",
	"serviceName":"",
	"isSecure":false,
	"data":""
};


var schoolYear = {
		"schoolYear":""
};

var subjectList = {
    "schoolYear" :"",
   "teacherId":""
 };

var studentDetails =[{
	"id": null,
	"schoolYear": "",
	"studentDetails": {
		"studentId": null
	},
	"subjectDetails": {
		"subjectId": null
	},
	"standardDetails": {
		"standardId": null
	},
	"scoreValue": "",
	"updatedBy": "",
	"lastUpdated": "",
	"spaceKey": ""
}];

var getData = {
		"spaceKey": "",
		"schoolYear": "",
		"teacherId": "",
		"subjectId": "",
		"className": "",
		"gradeLevel": "",
		"question": ""
	};

var tablejson = [{

		"componentType": "Dropdown",
		"options": "1,2,3,4"
	}];


var frequencyIntervalObject = {
							"freqIntervalName":"",
							"spaceKey":"",
							"metric_Frequency" : []
						};


var frequency = {
		"frequencyName": "",
		"orderValue": null,
		"spaceKey": "6494",
		"properties": {"startDate":"","endDate":""}
	};

var tableheader = {
		"value":"",
		"id":""
}