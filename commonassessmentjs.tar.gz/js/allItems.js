sisModule.controller('MyCtrl',['$scope','$mdSidenav','serverCall','$mdToast',function($scope,$mdSidenav,serverCall,$mdToast){
	
	$scope.showMobileMainHeader = true;
	$scope.schoolYear = new Date().getFullYear();
	$scope.selectedSchoolYear = new Date().getFullYear()-1;
	$scope.updatedDate = new Date();
	$scope.selectedquestion = "";
	$scope.schoolYearselect = angular.copy(schoolYear);
	$scope.teacherSelect = angular.copy(subjectList);
	$scope.teacherId1;
	$scope.savingStudentList = angular.copy(studentDetails);
	$scope.classNameByStudent = "" ;
	$scope.dataTable = angular.copy(tablejson);
	$scope.selectedSubjectID = "";
	$scope.selectedTeacherID ="";
	$scope.selectedGrade = "";
	$scope.selectedclassName ="";
	$scope.selectedQuestionName = "";
	$scope.getstudentList= [];
	$scope.subjects = "";
	
	$scope.openSideNavPanel = function() {
		$mdSidenav('left').open();
	};
	
	$scope.closeSideNavPanel = function() {
		$mdSidenav('left').close();
	};
	
	$scope.myDate = new Date();
	$scope.isOpen = false;
	
	// This function fetches the details of the number of columns required for the person details to display
	// The percentage of space taken by any column is being calculated here and stored inside the width field.
	$scope.getWidthAccTonumberOfColumn = function()
	{
		var i = 0;
		for(key in $scope.columnDetails)
		{
			if($scope.columnDetails[key].exists)
				i++;
		}
		return {"width" : 99/(i+1) +"%"};
	};
	
	//Listing school year in dropdown	
	
	$scope.setSchoolYear = function() {
		var selectedSchoolYearArray = [];
		var d = new Date();
		var currentyear = d.getFullYear();

		for(var schoolYear = currentyear-6 ; schoolYear < currentyear+4 ; schoolYear++) {
			selectedSchoolYearArray.push(schoolYear);
		}
		return selectedSchoolYearArray;
	};
	
	//On changes of school year
	$scope.onSchoolYearChange = function(schoolYear) {
		$scope.schoolYear = schoolYear;
		var data = {
				"schoolYear" : schoolYear+ ""
			};
		serverCall.getAllTeacherList(angular.toJson(data), 'getAllTeacherListAccordingSchoolYear',$scope.setTeacherList);
	};
	
	//On changes of school year 
	$scope.onSchoolYearChanges = function(schoolYear) {
		var data = {
				"schoolYear" : $scope.selectedSchoolYear+ ""
			};	
			serverCall.getAllTeacherList(angular.toJson(data), 'getAllTeacherListAccordingSchoolYear',$scope.setTeacherList);
	};
	
	// List teacher in dropdown
	'$mdToast'
	$scope.setTeacherList = function(response){
		$scope.teacherListArr = [];
		if(response.AssessmentResponse.teacherList !== undefined){
			for(key in response.AssessmentResponse.teacherList){
				$scope.teacherListArr.push(response.AssessmentResponse.teacherList[key]);
			}
		}
		else {
			$scope.showAlert("Teacher List Not Retrived Please Select Different School Year");
		}
			$scope.subjectListGet($scope.teacherListArr[0]);
	};
	
	
	$scope.subjectListGet = function(res){
		$scope.selectedTeacherID = res.teacherId+ "";
		var data = {
				/*"schoolYear":res.schoolYear+ "",*/
				"schoolYear":$scope.selectedSchoolYear+ "",
				"teacherId":res.teacherId+ ""
		};
		$scope.teacherId1=res.teacherId;
		serverCall.getAllSubjectList(angular.toJson(data), 'getAllSubjectList',$scope.setSubjectList);
	};
	
	$scope.setSubjectList = function(res){
		
		$scope.subjectListArr = [];
		$scope.$apply(function() {
		if(res.AssessmentResponse.subjectList !== undefined){
			for(key in res.AssessmentResponse.subjectList){
				$scope.subjectListArr.push(res.AssessmentResponse.subjectList[key]);
			}
		}else {
			$scope.showAlert("Subject List Not Retrived Please Select Different School Year And Teacher");
		}
		});
			$scope.GradeListGet($scope.subjectListArr[0]);
		
	};
	
	$scope.GradeListGet = function(res){
		$scope.selectedSubjectID = res.subjectId;
		var data = {
                "schoolYear":$scope.selectedSchoolYear+ "",
                "teacherId":$scope.teacherId1+ "",
                "subjectId":res.subjectId+ ""
		};
		serverCall.getAllGradeList(angular.toJson(data), 'getAllGradeList',$scope.setGradeList);
	};
	
	$scope.setGradeList = function(res){
		$scope.gradeListArr = [];
		$scope.$apply(function() {
		if(res.AssessmentResponse.teacherClassList !== undefined){
			for(key in res.AssessmentResponse.teacherClassList){
				$scope.gradeListArr.push(res.AssessmentResponse.teacherClassList[key]);
			}
		}else {
			$scope.showAlert("Grade List Not Retrived Please Select Different School Year And Teacher and Subject");
		}
		});
			$scope.ClassListGet($scope.gradeListArr[0]);
	};
	
	$scope.ClassListGet = function(res){
		$scope.selectedGrade = res.gradeLevel+"";
		var data = {
					"schoolYear":$scope.selectedSchoolYear+"",
	                "teacherId":res.teacherDetails.teacherId+"",
	                "subjectId":res.subjectDetails.subjectId+"",
	                "gradeLevel":res.gradeLevel+""
		};
		serverCall.getAllClassList(angular.toJson(data), 'getAllClassList',$scope.setClassList);
	};
	
	$scope.setClassList = function(res){
		$scope.classListArr = [];
		$scope.$apply(function() {
		if(res.AssessmentResponse.teacherClassList !== undefined){
			for(key in res.AssessmentResponse.teacherClassList){
				$scope.classListArr.push(res.AssessmentResponse.teacherClassList[key]);
			}

		}else {
			$scope.showAlert("Class List Not Retrived Please Select Different School Year And Teacher and Subject And Grade");
		}
		});
			$scope.QuestionListGet($scope.classListArr[0]);
	};
	
	$scope.QuestionListGet = function(res){
		$scope.selectedclassName =  res.className;
		var data = {
				"schoolYear" :$scope.selectedSchoolYear+"",
                "subjectId":res.subjectDetails.subjectId+"",
                "gradeLevel":res.gradeLevel+"",
		};
		$scope.classNameByStudent = res.className;
		serverCall.getAllQuestionList(angular.toJson(data),'getAllQuestionList',$scope.setQuestionList);
	};
	
	$scope.setQuestionList = function(res){
		$scope.questionListArr = [];// ARRAY FOR GETTING ALL THE QUESTIONS IN A PARTICULAR questionArray
		$scope.questionarr = [];// ARRAY FOR GETTING ALL THE UNIQUE QUESTIONS IN A PARTICULAR SUBJECT
		$scope.questionArray = [];// ARRAY FOR GETTING ALL THE QUESTIONS IN A PARTICULAR SUBJECT
		$scope.ques = [];
		$scope.$apply(function() {
		if(res.AssessmentResponse.questionStandardList !== undefined){
			for(key in res.AssessmentResponse.questionStandardList){
				// TO CHECK UNIQUE ENTRY OF QUESTIONS.
				if($scope.questionarr.indexOf(res.AssessmentResponse.questionStandardList[key].question) === -1){
					//PUSHING THE UNIQUE QUESTIONS INSIDE THE ARRAY OF QUESTIONS.
					$scope.questionarr.push(res.AssessmentResponse.questionStandardList[key].question);
				}
				
				$scope.questionArray.push(res.AssessmentResponse.questionStandardList[key]);
			}
			
			for(key in $scope.questionArray){
                  if($scope.questionarr[0] === $scope.questionArray[key].question){
                	  $scope.questionListArr.push(res.AssessmentResponse.questionStandardList[key]);
                  }
			}
		}
		else {
			$scope.showAlert("Question List Not Retrived Please Select Different Class And Grade And Subject");
		}
		
		for(var i=0; i<$scope.questionListArr.length;i++){
			$scope.questionListArr[i].scoreValue ="";
		}
		});
		$scope.getQuestionName($scope.questionListArr[0].question);
	};
	
	$scope.getQuestionName = function(res){
		$scope.selectedQuestionName = res;
		$scope.getStudentLists();
	}
	
	$scope.getStudentLists = function(res){
		$scope.selectedquestion = res;
		var data = {
				"schoolYear":$scope.selectedSchoolYear+"",
                "className":$scope.classNameByStudent+""
		};
		serverCall.getAllStudentList(angular.toJson(data),'getAllStudentList',$scope.setStudentList);
	};
	
	$scope.setStudentList = function(res){
		console.log(res);
		$scope.studentListArr = [];
		$scope.studentMap = [];
		$scope.$apply(function() {
		if(res.AssessmentResponse.studentClassList !== undefined){
			for(key in res.AssessmentResponse.studentClassList){
				$scope.studentListArr.push(res.AssessmentResponse.studentClassList[key]);
			}
		}else {
			$scope.showAlert("Student List Not Retrived Please Select Different Class And School Year");
		}
		});
		$scope.createMap();
	};
	
	$scope.setQuestionAccordingLabel = function(question){
		$scope.questionListArr = [];
		for(key in  $scope.questionArray){
			if(question == $scope.questionArray[key].question){
				$scope.questionListArr.push($scope.questionArray[key]);
			}
		}
		$scope.getStudentLists();
	};
	
	$scope.createMap = function(){
		var parentChildMap = {};
  		$scope.studentData = {};
  		$scope.$apply(function() {
  		for(var i = 0; i < $scope.studentListArr.length; i++)
  		{
  			if(parentChildMap[$scope.studentListArr[i].id] == undefined)
  			{
  				parentChildMap[$scope.studentListArr[i].id] = [];
  			}
  			parentChildMap[$scope.studentListArr[i].id].push($scope.studentListArr[i].studentDetails.studentId);

  			var copiedFormula = jQuery.extend(true, angular.copy($scope.questionListArr), angular.fromJson($scope.studentListArr[i].question));
  			$scope.studentData[$scope.studentListArr[i].studentDetails.studentId] = $scope.studentListArr[i];
  			$scope.studentData[$scope.studentListArr[i].studentDetails.studentId].question = copiedFormula;//angular.fromJson($scope.metricData[$scope.MetricMap[i].metricID].formula);
  		}
  		});
  		$scope.getdatasave();
	};

	$scope.setValue = function(){
		console.log($scope.selectedQuestionName);
		$scope.updateIdData = [];
		$scope.$apply(function() {
		 if($scope.getstudentList.length !==0){
			 for(key in $scope.studentListArr){
			 	var j = 0;
			 	
			 	if($scope.studentListArr[key].studentDetails.studentId == $scope.getstudentList[key].studentDetails.studentId){
			 			var k = 0;
			 		for(var i=0; i<$scope.getstudentList[key].standardDetails.length;i++){
			 			 var updateDATA = {"id":"","studentID":""};
		 					updateDATA.id = $scope.getstudentList[key].standardDetails[i].id;
		 					updateDATA.studentID = $scope.getstudentList[key].studentDetails.studentId;
			 				$scope.updateIdData.push(updateDATA);
			 			 if($scope.getstudentList[key].standardDetails[i].questionName ==$scope.selectedQuestionName){
			 				$scope.studentListArr[key].question[j].scoreValue = $scope.getstudentList[key].standardDetails[i].scoreValue;
			 				 j = j+1;
			 				 if(k==3){
			 				 	k = 0;
			 				  
			 				 }else{
			 				 	 k = k+1;
			 				 }		
			 			}
			 		}
			 	}
			 }
		}
		});
	};
	
	$scope.saveStudentData = function(res){
		$scope.arrayOFStudent = [];
		var h = 0;
		console.log($scope.updateIdData);
			for(key in $scope.studentListArr){
				for(var k=0; k<$scope.studentListArr[key].question.length;k++){
					
				if($scope.updateIdData.length !== 0){
					if((isNaN($scope.studentListArr[key].question[k].scoreValue))
							||($scope.studentListArr[key].question[k].scoreValue===''))
					{
						$scope.studentListArr[key].question[k].scoreValue='0';
					}
					if(($scope.studentListArr[key].question[k].scoreValue<='4'&& 
							$scope.studentListArr[key].question[k].scoreValue>='0'))
					{	}
					else{
						$scope.showAlert("Please enter number between 0 and 4 in the fields!");
						return;
					}
					var student = {};
					student = angular.copy(studentDetails);
					student[0].id =$scope.updateIdData[h].id; 
					var h = h+1;
					student[0].lastUpdated = new Date();
					student[0].schoolYear = $scope.studentListArr[key].schoolYear;
					student[0].scoreValue = $scope.studentListArr[key].question[k].scoreValue+"";
					student[0].spaceKey = ""+ $scope.userDetails.user.spaceKey + "";
					student[0].standardDetails.standardId = $scope.studentListArr[key].question[k].standardDetails.standardId;
					student[0].studentDetails.studentId = $scope.studentListArr[key].studentDetails.studentId;
					student[0].subjectDetails.subjectId = $scope.studentListArr[key].question[k].subjectDetails.subjectId;
					$scope.arrayOFStudent.push(student[0]);
					
				}else{
					var student = {};
					student = angular.copy(studentDetails);
					student[0].id =null; 
					student[0].lastUpdated = new Date();
					student[0].schoolYear = $scope.studentListArr[key].schoolYear;
					student[0].scoreValue = $scope.studentListArr[key].question[k].scoreValue+"";
					student[0].spaceKey =  ""+ $scope.userDetails.user.spaceKey + "";
					student[0].standardDetails.standardId = $scope.studentListArr[key].question[k].standardDetails.standardId;
					student[0].studentDetails.studentId = $scope.studentListArr[key].studentDetails.studentId;
					student[0].subjectDetails.subjectId = $scope.studentListArr[key].question[k].subjectDetails.subjectId;
					$scope.arrayOFStudent.push(student[0]);
				}
			}
		}
		
		//serverCall.confirmationBox("This will save Student Assessment Score", angular.toJson($scope.arrayOFStudent),'saveAssessmentScore',$scope.getdatasave);
		serverCall.saveData(angular.toJson($scope.arrayOFStudent),'saveAssessmentScore',$scope.getdatasave);
	};
    
	$scope.showCustomToast = function(message) {
        $mdToast.show({
          hideDelay   : 3000,
          position    : 'top right',
          message	  : message
        });
    };
	
	$scope.getdatasave = function(res){
		if(res !== undefined){
			$scope.showAlert(res.AssessmentResponse.message,"noError");
			//$scope.showCustomToast(res.AssessmentResponse.message);
		}
		var r = angular.copy(getData);
		r.spaceKey =  ""+ $scope.userDetails.user.spaceKey + "";
		r.schoolYear = $scope.selectedSchoolYear+"";
		r.teacherId = $scope.selectedTeacherID+"";
		r.subjectId = $scope.selectedSubjectID+"";
		r.className = $scope.selectedclassName+"";
		r.gradeLevel =	$scope.selectedGrade+"";
		r.question = $scope.selectedQuestionName+"";
		
		$scope.getstudentDatas(r);
	};
	
	$scope.getstudentDatas = function(res){
			serverCall.getAllStudentwithScoreValue(angular.toJson(res),$scope.setstudentData);
	};	
	
	$scope.setstudentData = function(response){
		$scope.subject = [];
		$scope.QuestionData = [];
		$scope.classData = [];
		if(response.AssessmentResponse.scoreList !== undefined){
			var obj = JSON.parse(response.AssessmentResponse.scoreList);
				  	$scope.getstudentList = [];
				  for(key in obj.evaluatedScoresList){
				  	$scope.getstudentList.push(obj.evaluatedScoresList[key]);
			}
			}
			  $scope.setValue(); 
	};
			
	$scope.setData = function(){
		  for(key in $scope.getstudentList){
			  for(var i=0;i<$scope.getstudentList[key].standardDetails.length;i++){
					var data = {
							"schoolYear" :$scope.getstudentList[key].schoolYear+"",
			                "standardId":$scope.getstudentList[key].standardDetails[i].standardId+"",
					};
					serverCall.getQuestionByStandard(angular.toJson(data),'getQuestionByStandard',$scope.questionList);
			  }
		  }
	};
		
	$scope.questionList = function(res){
		if(res.AssessmentResponse.questionStandard !== undefined){
		  $scope.subject.push(res.AssessmentResponse.questionStandard);
		  for(key in  $scope.subject){
				if($scope.QuestionData.indexOf($scope.subject[key].question) === -1){
				$scope.QuestionData.push($scope.subject[key].question);
			}
				$scope.classData.push($scope.subject[key]);
		  }
		}
	};
	
	
	$scope.getWidthAccTonumberOfColumn= function(student){
		$scope.studentData = [];
		$scope.studentData.push(student);
	};
	
	$scope.frequencyData = angular.copy(frequency);
  
	$scope.frequencyTable = true;
	$scope.frequencyForm = false;
	
	$scope.onClickForForm = function(){
		if ($scope.frequencyTable) {
			$scope.frequencyTable = false;
			$scope.frequencyForm = true;
		} else {
			$scope.frequencyTable = true;
			$scope.frequencyForm = true;
		}
	};
	
	$scope.onClickForData = function(){
		if ($scope.frequencyForm) {
			$scope.frequencyTable = true;
			$scope.frequencyForm = false;
		} else {
			 

			$scope.frequencyTable = true;
			$scope.frequencyForm = true;
		}
	};
	
	$scope.onSchoolYearChanges();
}]);
/*sisModule.directive('autosave',[function(){
	'use strict';
	function autosaveController($scope,$element,$attrs){
		function saveModel(newModel,oldModel){
			
		}
		$scope.$watch($attrs.model,_.debounce(saveModel,5000),true);
	}
}]);*/
