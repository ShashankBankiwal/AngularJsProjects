/*(function(){*/
angular.module('GanttChart').filter('unique',function(){
	return function(collection,keyname){
		var output1=[],keys=[];
		
		angular.forEach(collection,function(item){
			var key=item[keyname];
			if(keys.indexOf(key)===-1 && key!=undefined && key!=1970){
				keys.push(key);
				output1.push(item);
			}
		});
		
		return output1;
	};
});

/*})();*/