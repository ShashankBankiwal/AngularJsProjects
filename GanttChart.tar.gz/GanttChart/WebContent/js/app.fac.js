(function(){
	"use strict";
	
	angular.module("GanttChart")
			.factory("ganttFactory",function($http){
				
			function getData(){
				return $http.get('data/gantt.json');
			}
			
			return {
				getData:getData
			}
		})
		.factory("iconFactory",function($http){
			function getIcons(){
				return $http.get('data/icon.json');
			}
			
			return {
				getIcons:getIcons
			}
		});
})();
