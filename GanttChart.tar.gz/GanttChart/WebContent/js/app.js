var app=angular.module("GanttChart",['ngRoute','ngMaterial','ngMessages']);

app.controller("ganttController",function($scope,$http,ganttFactory,iconFactory){
			
			$scope.maxYear,$scope.minYear;
			$scope.lWidth;
			$scope.finaldata;
			var calc=[];
			var re=/\d{4}-\d{2}-\d{2} 00:00:00\.0/g;
			/*$scope.data={};*/
			
			ganttFactory.getData().then(function(getData){
				$scope.dataset=getData.data;
				
				//All the functions below are called at the time of loading of the service by the controller
			
	/*1*/		
	/*2*/		$scope.getStartDate();
	/*3*/		$scope.getEndDate();
				$scope.changedData();
	/*4*/		$scope.getYearRange();	
	/*5*/		/*$scope.calculations();*/
				/*$scope.changedData();*/
	/*6*/		/*$scope.getMonthRange();*/
			
			});
			
			iconFactory.getIcons().then(function(icons){
				$scope.iconset=icons.data;
				console.log($scope.iconset);
			});
/*For calculating new data which is being updated in the $scope.dataset which is updated*/
		
/*1*/		$scope.changedData=function(){
				
	//By the help of this array we are getting the changed 
				//data which is giving us only a single iteration for the first column
				
				var array={};
				for(var i=0;i<$scope.dataset.length;i++){
					
					if(!array[$scope.dataset[i].histology]){
						//In the next line we are making an array of objects which contains object as the array parameter.
						array[$scope.dataset[i].histology]=new Array();
					}
					array[$scope.dataset[i].histology].push($scope.dataset[i]);
				}
				$scope.finaldata=array;
				/*console.log($scope.finaldata);*/
				var date=Date();
				/*console.log(date);*/
				/*console.log($scope.minYear+"  "+$scope.maxYear);*/
				/*$rootScope.$broadcast('draw',{});*/
				
			}	
		
/*For calculation of the minimum year and minimum month of the data given.*/
			
/*2*/		$scope.getStartDate=function(){
	
			var minYear=3000,minMonth=3000;
			
			/*We are using forEach loop because we are having Json array in which we have many objects( equal to 72)
			 * So we have to iterate through each object item and parse the protocol_completion_operational field*/
			var a=0;
			angular.forEach($scope.dataset,function(item){	
				var tempDate = item.protocol_completion_operational;
				
				if(tempDate!=null && String(tempDate.match(re)!=null)){
					
					var temp = new Date(tempDate);
					
					$scope.dataset[a].startYear = temp.getFullYear();
					$scope.dataset[a].startMonth = temp.getMonth();
					
				
					
					if($scope.dataset[a].startYear<minYear){
						minYear=$scope.dataset[a].startYear;
					}
					if($scope.dataset[a].startMonth<minMonth){
						minMonth=$scope.dataset[a].startMonth;
					}
				}
				a++;
				
				
			});
			
			$scope.minYear=minYear;
			/*console.log("MinYear:"+minYear);*/
			$scope.minMonth=minMonth;
			/*console.log("MinMonth"+minMonth);*/
		}
		
		
		/*For calculation of the end date of the task. This would give us the maximum value for the month and the year available*/
		
/*3*/		$scope.getEndDate=function(){	
			
			var maxYear=0,maxMonth=0;
			var a=0;
			angular.forEach($scope.dataset,function(item){
				
					var tempDate=item.final_csr;
					
					if(tempDate!=null && String(tempDate.match(re)!=null)){
						
						var temp=new Date(tempDate);
						$scope.dataset[a].endYear=temp.getFullYear();
						$scope.dataset[a].endMonth = temp.getMonth();
						if($scope.dataset[a].endYear>maxYear){
							maxYear=$scope.dataset[a].endYear;
						}
						if($scope.dataset[a].endMonth>maxMonth){
							maxMonth=$scope.dataset[a].endMonth;
						}
					}
				a++;
				
			});
			$scope.maxYear=maxYear;
			/*console.log("MaxYear"+maxYear);*/
			$scope.maxMonth=maxMonth;
			/*console.log("MaxMonth"+maxMonth);*/
			
			
		}
		
		/*For calculation of the location of the start and end for a particular line */
		
/*4*/	$scope.calculations=function(){
			var x=0;
			
			/*var calcArray=[];*/
			angular.forEach($scope.dataset,function(item){
				
				var startDate = item.protocol_completion_operational;
				var endDate=item.final_csr;
				
				if(startDate!=null && String(startDate.match(re)!=null) && endDate!=null && String(endDate.match(re)!=null)){
				var startD = new Date(startDate);
				var endD = new Date(endDate);
				/*var tempObj ={};*/
				var startYear = startD.getFullYear();
				/*console.log("MinYear:"+$scope.minYear);*/
				/*console.log("StartYear:"+startYear);*/
				var endYear = endD.getFullYear();
				/*console.log("MaxYear"+$scope.maxYear);*/
				/*console.log("EndYear"+endYear);*/
				var startMonth = startD.getMonth();
				/*console.log("StartMonth"+startMonth);*/
				var endMonth = endD.getMonth();
				var start,finish;
				/*if(startYear!=1970){*/
					start=startYear-$scope.minYear;
					/*console.log("Start1"+start);*/
					if(start>=0){
						start=start*65.45;//for calculating gap between start and 0 position.
						/*console.log("Start2:"+start);*/
						var m1=startMonth+1;//The index which we get from getMonth() method is from 0 so we add +1 here
						m1=m1*(5.45416667);
						/*console.log("M1 "+m1);*/
						start=start+m1;
						/*console.log("Start3 "+start);*/
					}
					else{
						start=0;
					}
					/*if($scope.maxYear>=endYear){
						
						
						if(endYear>$scope.maxYear){
							finish=endYear-$scope.maxYear;
						}
						else{
							finish=$scope.maxYear-endYear;
						}
						finish=finish*68;
						var m2=endMonth;
						m2=m2*(6);
						finish=finish-m2;
						finish=1104-finish;
						console.log("Finish for"+ $scope.maxYear+" "+ finish);
					}*/
					if($scope.maxYear>=endYear){
					finish = endYear-$scope.minYear;
					/*console.log("Finish1"+finish);*/
						if(finish>=0){
							finish = endYear-$scope.minYear;
							finish=finish*65.45;
							/*console.log("Finish:"+finish);*/
							var m2=endMonth+1;//The index which we get from getMonth() method starts from 0 so we add +1
							m2=m2*(5.45416667);
							/*console.log("M2 "+m2);*/
							
							finish=finish+m2;
							/*console.log("Finish "+finish);
							console.log("Finish2:"+finish);*/
						}
					}
					else{
						finish=$scope.lWidth;
					}
					/*console.log("Final values");
				console.log(start);
				console.log(finish);*/
				$scope.dataset[x].startLine=start;
				$scope.dataset[x].finishLine=finish;
				
				}
				/*$rootScope.$broadcast('draw',{});*/
				x++;
			});
			/*angular.forEach($scope.dataset,function(key,item){
					angular.forEach($scope.iconset,function(iconkey){
						var name=iconkey.name;
						console.log("Name:"+name);
						console.log("Key:"+key);
						console.log("Item:"+item);
					})
			})*/
			
			for(var i=0;i<$scope.dataset.length;i++){
				var j=$scope.dataset[i];
				$scope.dataset[i].positions=[];
				
				for(k in j){
					var itemnumber=0;
					angular.forEach($scope.iconset,function(item){
						
						if(k.match(item.name)){
							var temp=j[k];
							if(temp!=null && String(temp.match(re)!=null)){
								temp=new Date(j[k]);
								console.log("Value of key k:"+j[k]);
								console.log("Val of k:"+k);
								var year=temp.getFullYear();
								var month=temp.getMonth();
								
								var location=year-$scope.minYear;
								if(location>=0){
									location=location*65.45;//for calculating gap between start and 0 position.
									/*console.log("Start2:"+start);*/
									var m=month+1;//The index which we get from getMonth() method is from 0 so we add +1 here
									m=m*(5.45416667);
									/*console.log("M1 "+m1);*/
									location=location+m;
									/*console.log("Start3 "+start);*/
								}
								else{
									location=0;
								}
								/*console.log("Position of k:"+positions);*/
								var itemName=item.name;
								$scope.dataset[i].positions.push(angular.copy({itemName:location}));
								/*$scope.dataset[i].positions[itemnumber]={itemName:location};
								*/console.log($scope.dataset[i].positions);
							}
						}
						/*console.log("Item Number:"+itemnumber);*/
						itemnumber++;
					});
				}
			}
			$scope.changedData();
		}
		
		/* This function would be called on click of any of the year button. This function sets the value of
		 * the  */
		
/*5*/	$scope.getYearRange=function(){
			
				var years=[];
				if($scope.minYear<$scope.maxYear){
					for(var i=$scope.minYear;i<=$scope.maxYear;i++){
						years.push(i);
					}
					$scope.years=years;
				}
				
				
				$scope.lWidth=(($scope.maxYear-$scope.minYear)+1)*68;
				/*console.log("Count :"+ $scope.lWidth);*/
				
				var months=[];
				if($scope.maxYear>$scope.minYear){
				$scope.count=$scope.maxYear-$scope.minYear+2;
				$scope.count=$scope.count*4;
				for(var i=1;i<=$scope.count;i++){
					if(i>4){
						if((i%4)==0){months.push(4);}
						else{months.push(i%4);}
					}
				}
				$scope.months=months;
				}
				$scope.calculations();
		}	
			
			/*$scope.start,$scope.end;
			angular.forEach(content,function(item){
				var startDate = item.protocol_completion_operational;
				var endDate=item.final_csr;
				var tempObj ={};
				tempObj.startYear = startDate.getFullYear();
				tempObj.endYear = endDate.getFullYear();
				tempObj.startMonth = startDate.getMonth();
				tempObj.endMonth = endDate.getMonth();
				if($scope.minYear<tempObj.startYear){
					var start=tempObj.startYear-$scope.minYear;
					start=start*72;//for calculating gap between start and 0 position.
					var y=$scope.startMonth;
					y=y*6;
					start=start+y;
				}
				if($scope.maxYear>tempObj.endYear){
					var end =$scope.maxYear-tempObj.endYear;
					end=end*72;//for calculating gap between start and 0 position.
					var y=$scope.endMonth;
					y=y*6;
					end=end-y;
				}
				$scope.start=start;
				$scope.end=end;*/
			
		
		
		
/*6*/	$scope.getMonthRange=function(minMonth,maxMonth){
			var months=[];
			for(var i=minMonth;i<maxMonth;i++){
				months.push(i);
			}
			$scope.months= months;
		}
		
		
		$scope.getData = function(content1,content2){
			if(content1==content2[0]){
				return true;
			}
			else{
				return false;
			}
		}
});

/*app.directive('drawLine',function(){
	return{
	scope:
		{
			x:'@x',
			a:'@a',
			b:'@b'
		},
	link: function(scope,element,attrs)
		{
			scope.draw = function() { console.log("DRAW");
			
			var x=parseInt(scope.x);
			var a=parseInt(scope.a);
			var b=parseInt(scope.b);
			console.log("Directive x:"+x);
			console.log("Directive a:"+a);
			var canvas=element.parent();
			var ctx=canvas[0].getContext("2d");
			ctx.clearRect(0,0,b,25);
			ctx.beginPath();
			ctx.strokeStyle="#A9A9A9";
			ctx.moveTo(x,3.5);
			ctx.lineTo(a,3.5);
			ctx.lineWidth=10;
			ctx.stroke();
			ctx.fill();
			};
			
			scope.draw();
			
			scope.$on('draw',function(event,data){
	             scope.draw();
	         });
			bindToController: true
			controller:'ganttController'
		}
		
	}
});*/


/*function getData(content){
	var histology=[];
	angular.forEach(content,function(item){
		angular.forEach(item,function(data){
			histology.push(data);
		});
	});
	return _.uniq(histology);
}*/
/*function getCategories(classifieds){
	
	var categories=[];
	
	angular.forEach(classifieds,function(item){
		angular.forEach(item.categories,function(category){
			categories.push(category);
		});
	});
	
	return _.uniq(categories);
}	*/	

/*$http.get('data/gantt.json').then(function(response){
$scope.dataset=response.data;
$scope.changedData($scope.dataset);
});*/

/*$scope.minYear;
$scope.maxYear;
$scope.values;
$scope.dataset=$scope.values;
$scope.changedData($scope.dataset);
$scope.getStartDate($scope.dataset);
$scope.getEndDate($scope.dataset);
$scope.calculations($scope.dataset)
$scope.getYearRange($scope.minYear,$scope.maxYear,$scope.calculations($scope.dataset));
$scope.getMonthRange($scope.minMonth,$scope.maxMonth);*/


/*$scope.changedData($scope.dataset);
$scope.getStartDate($scope.dataset);
$scope.getEndDate($scope.dataset);
$scope.getYearRange($scope.minYear,$scope.maxYear,$scope.calculations($scope.dataset));*/
/*$scope.getMonthRange($scope.minMonth,$scope.maxMonth);*/
/*$scope.minMonth=0;
$scope.maxMonth=10;
$scope.minYear=2010;
$scope.maxYear=2016;*/

/*$scope.myStartDate
$scope.myEndDate
console.log($scope.myStartDate);
console.log($scope.myEndDate);*/



























/*var app=angular.module("GanttChart",['ngRoute','ngMaterial','ngMessages']);

app.controller("ganttController",function($scope,$http,ganttFactory, $rootScope){
			$scope.dataset;
			$scope.value=$scope.dataset;
			$scope.maxYear=0,$scope.minYear=0;
			$scope.count=0;
			$scope.content=0;
			ganttFactory.getData().then(function(getData){
				$scope.content=getData.data;
				console.log($scope.content);
			});
			
			$scope.changedData();
			$scope.getStartDate();
			$scope.getEndDate();
			$scope.calculations();
//			function getYearRange($scope.minYear,$scope.maxYear,$scope.calculations($scope.dataset));
			$scope.getYearRange();
			$scope.getMonthRange();
			
		
		
		For calculation of the minimum year and minimum month of the data given.
			
		$scope.getStartDate=function(){
			
			var array1=[];
			var minYear=3000,minMonth=20;
			var content=$scope.content;
			angular.forEach(content,function(item){	
				var tempDate = item.protocol_completion_operational;
				var temp = new Date(tempDate);
				var tempObj ={};
				tempObj.year = temp.getFullYear();
				tempObj.month = temp.getMonth();
				if(tempObj.year<minYear && tempObj.year!=null){
					minYear=tempObj.year;
				}
				if(tempObj.month<minMonth){
					minMonth=tempObj.month;
				}
				array1.push(tempObj);
			});
			$scope.startDateJson=array1;
			if(minYear<2010){
				$scope.minYear=2010;
			}
			else{
				$scope.minYear=minYear;
			}
			$scope.minYear=minYear;
			$scope.minMonth=minMonth;
			$scope.startYear=minYear;
			$scope.startMonth=minMonth;
			console.log(angular.toJson(array)+"__length"+array.length);
			console.log(minYear);
			console.log(minMonth);
		}
		
		
		For calculation of the end date of the task. This would give us the maximum value for the month and the year available
		
		$scope.getEndDate=function(){
			var array2=[];
			var maxYear=0,maxMonth=-1;
			var content=$scope.content;
			angular.forEach(content,function(item){
				
					var tempDate=item.final_csr;
					
					var temp=new Date(tempDate);
					var tempObj={};
					tempObj.year=temp.getFullYear();
					tempObj.month = temp.getMonth();
					if(tempObj.year>maxYear && tempObj.year!=null){
						maxYear=tempObj.year;
					}
					if(tempObj.month>maxMonth){
						maxMonth=tempObj.month;
					}
				
				array2.push(tempObj);
			});
			$scope.maxYear=maxYear;
			$scope.maxMonth=maxMonth;
			$scope.endDateJson=array2;
			$scope.endYear=maxYear;
			$scope.endMonth=maxMonth;
			console.log(angular.toJson(array)+"__length"+array.length);
			console.log(maxYear);
			console.log(maxMonth);
		}
		
		For calculation of the location of the start and end for a particular line 
		
		$scope.calculations=function(){
			var x=0;y=0;
			var calcArray=[];
			var content=$scope.content;
			angular.forEach(content,function(item){
				
				var startDate = item.protocol_completion_operational;
				var startD = new Date(startDate);
				var endDate=item.final_csr;
				var endD = new Date(endDate);
				var tempObj ={};
				var startYear = startD.getFullYear();
				var endYear = endD.getFullYear();
				var startMonth = startD.getMonth();
				var endMonth = endD.getMonth();
				if($scope.minYear<startYear){
					var start;
					if(startYear>$scope.minYear){
						start=startYear-$scope.minYear;
					}
					else{
						start=$scope.minYear-startYear;
					}
					var start=startYear-$scope.minYear;
					start=start*72;//for calculating gap between start and 0 position.
					var m1=startMonth;
					m1=m1*6;
					start=start+m1;
					console.log("Start for"+$scope.minYear+" " + start);
				}
				if($scope.maxYear>endYear){
					
					var finish = $scope.maxYear-endYear;
					if(endYear>$scope.maxYear){
						finish=endYear-$scope.maxYear;
					}
					else{
						finish=$scope.maxYear-endYear;
					}
					finish=finish*68;
					var m2=endMonth;
					m2=m2*(6);
					finish=finish-m2;
					finish=1104-finish;
					console.log("Finish for"+ $scope.maxYear+" "+ finish);
				}
				tempObj.start=start;
				tempObj.finish=finish;
				content[x++].start=start;
				content[y++].finish=finish;
			});
			var array={};
			for(var i=0;i<content.length;i++){
				
				if(!array[content[i].histology]){
					array[content[i].histology]=new Array();
				}
				array[content[i].histology].push(content[i]);
			}
			
			console.log("CALLED");
			console.log(array);
			$scope.finaldata=array;
			$rootScope.$broadcast('draw',{});
			
		}
		
		 This function would be called on click of any of the year button. This function sets the value of
		 * the  
		
		$scope.getYearRange=function(){
			var content=$scope.content;
			var years=[];
			if($scope.minYear<$scope.maxYear){
				for(var i=$scope.minYear;i<=$scope.maxYear;i++){
					years.push(i);
			}
				$scope.years=years;
			}
			$scope.count=($scope.maxYear-$scope.minYear+1)*68+16;
			console.log("Count"+$scope.count);
			var months=[];
			if($scope.maxYear>$scope.minYear){
			$scope.count=$scope.maxYear-$scope.minYear+2;
			$scope.count=$scope.count*4;
			for(var i=1;i<=$scope.count;i++){
				if(i>4){
					if((i%4)==0){months.push(4);}
					else{months.push(i%4);}
				}
			}
			$scope.months=months;
			}
			$scope.calculations($scope.dataset);
		}	
			
			$scope.start,$scope.end;
			angular.forEach(content,function(item){
				var startDate = item.protocol_completion_operational;
				var endDate=item.final_csr;
				var tempObj ={};
				tempObj.startYear = startDate.getFullYear();
				tempObj.endYear = endDate.getFullYear();
				tempObj.startMonth = startDate.getMonth();
				tempObj.endMonth = endDate.getMonth();
				if($scope.minYear<tempObj.startYear){
					var start=tempObj.startYear-$scope.minYear;
					start=start*72;//for calculating gap between start and 0 position.
					var y=$scope.startMonth;
					y=y*6;
					start=start+y;
				}
				if($scope.maxYear>tempObj.endYear){
					var end =$scope.maxYear-tempObj.endYear;
					end=end*72;//for calculating gap between start and 0 position.
					var y=$scope.endMonth;
					y=y*6;
					end=end-y;
				}
				$scope.start=start;
				$scope.end=end;
			
		
		
		
		$scope.getMonthRange=function(minMonth,maxMonth){
			var months=[];
			for(var i=minMonth;i<maxMonth;i++){
				months.push(i);
			}
			$scope.months= months;
		}
		
		
		
		
		$scope.changedData=function(){
			//By the help of this array we are getting the changed 
			//data which is giving us only a single iteration for the first column
			var content=$scope.content;
			var array={};
			for(var i=0;i<content.length;i++){
				
				if(!array[content[i].histology]){
					array[content[i].histology]=new Array();
				}
				array[content[i].histology].push(content[i]);
			}
			$scope.finaldata=array;
		}
		
		$scope.getData = function(content1,content2){
			if(content1==content2[0]){
				return true;
			}
			else{
				return false;
			}
		}
});

app.directive('drawLine',function(){
	return{
	scope:
		{
			x:'@x',
			a:'@a'
		},
	link: function(scope,element,attrs)
		{
			scope.draw = function() { console.log("DRAW");
		
			var x=parseInt(scope.x);
			var a=parseInt(scope.a);
			var canvas=element.parent();
			var ctx=canvas[0].getContext("2d");
			ctx.beginPath();
			ctx.strokeStyle="#A9A9A9";
			ctx.moveTo(x,3.5);
			ctx.lineTo(a,3.5);
			ctx.lineWidth=10;
			ctx.stroke();
			ctx.fill();
			};
			
			scope.draw();
			
			scope.$on('draw',function(event, data){
	             scope.draw();
	         });
			
		}
	}
});


function getData(content){
	var histology=[];
	angular.forEach(content,function(item){
		angular.forEach(item,function(data){
			histology.push(data);
		});
	});
	return _.uniq(histology);
}
function getCategories(classifieds){
	
	var categories=[];
	
	angular.forEach(classifieds,function(item){
		angular.forEach(item.categories,function(category){
			categories.push(category);
		});
	});
	
	return _.uniq(categories);
}		

$http.get('data/gantt.json').then(function(response){
$scope.dataset=response.data;
$scope.changedData($scope.dataset);
});

$scope.minYear;
$scope.maxYear;
$scope.values;
$scope.dataset=$scope.values;
$scope.changedData($scope.dataset);
$scope.getStartDate($scope.dataset);
$scope.getEndDate($scope.dataset);
$scope.calculations($scope.dataset)
$scope.getYearRange($scope.minYear,$scope.maxYear,$scope.calculations($scope.dataset));
$scope.getMonthRange($scope.minMonth,$scope.maxMonth);


$scope.changedData($scope.dataset);
$scope.getStartDate($scope.dataset);
$scope.getEndDate($scope.dataset);
$scope.getYearRange($scope.minYear,$scope.maxYear,$scope.calculations($scope.dataset));
$scope.getMonthRange($scope.minMonth,$scope.maxMonth);
$scope.minMonth=0;
$scope.maxMonth=10;
$scope.minYear=2010;
$scope.maxYear=2016;

$scope.myStartDate
$scope.myEndDate
console.log($scope.myStartDate);
console.log($scope.myEndDate);*/