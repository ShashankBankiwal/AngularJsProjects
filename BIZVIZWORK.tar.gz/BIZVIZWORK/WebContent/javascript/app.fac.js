(function(){
	"use strict";
	
	angular
	.module("Bizviz")
	.factory("detailsFactory",function($http){
		function getDetails(){
			return $http.get('json/details.json');
		}
		return {
			getDetails: getDetails
		}
	});
})();
