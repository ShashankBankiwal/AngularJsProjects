angular
.module('Bizviz')
.component('homeDetails',{
	template:'<home></home>',
	controller:['$routeParams',function HomeController($routeParams){
		
	}]
});