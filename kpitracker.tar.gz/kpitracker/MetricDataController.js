metricModule.controller('MetricDataController',['$scope', '$filter', function( $scope, $filter)
{
	$scope.$parent.MetricMap = [];
  	$scope.$parent.parentChildMap = {};
  	$scope.$parent.metricData = {};
  	$scope.$parent.currentMetricData = {};
  	$scope.$parent.previousMetricData = {};
	
	$(".nav").find(".active").removeClass("active");
	$(".nav > li[value='4']").addClass("active");

	$scope.columnDetails = {};
	$scope.FrequencyArray = [];

	$scope.getWidthAccTonumberOfColumn = function()
	{
		var i = 0;
		for(key in $scope.columnDetails)
		{
			if($scope.columnDetails[key].exists)
				i++;
		}
		return {"width" : 99/(i+1) +"%"};
	};

	$scope.setSchoolYear = function()
	{
		var selectedSchoolYearArray = [];
		var d = new Date();
		var currentyear = d.getFullYear();

		for(var schoolYear = currentyear-6 ; schoolYear < currentyear+4 ; schoolYear++)
		{
			selectedSchoolYearArray.push(schoolYear);
		}
		return selectedSchoolYearArray;
	};
	
	$scope.setSchoolYearAccordingToMonth = function()
	{
		var monthList = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

		var d = new Date();
		var currentmonth = d.getMonth();
		var currentYear = new Date().getFullYear();

		var selectedMonth = $scope.$parent.selectedForm.yearStartMonth;

		var index = monthList.indexOf(selectedMonth);

		if(currentmonth < index)
			$scope.$parent.selectedSchoolYear = currentYear-1;

		$('#dropDownSchoolYear').html($("#schoolYear-" + $scope.$parent.selectedSchoolYear).html() + '<span class="caret"></span>');
	};

	$scope.formSelector = function()
	{
		$scope.manageTheme();
		$(".loader").fadeOut("slow");

		if($scope.FormMap.length > 0)
		{
			$('#myModal2').modal({
				backdrop: 'static',
				show: true,
		   	});
		}
	};

	$scope.formChange = function(formObject)
	{
		$scope.$parent.selectedForm = formObject;
		$scope.$parent.selectedFormID = formObject.formID;

		$scope.setSchoolYearAccordingToMonth();
		$scope.getAllCategoryFromService($scope.firstCategorySelected);
	};
	
	$scope.firstCategorySelected = function()
	{
		$('#ulCategory a:first').click();
		$(".loader").fadeOut("slow");
	};

	$scope.categoryChange = function(categoryObject)
	{
		$scope.$parent.selectedCategory = categoryObject;
		$scope.$parent.selectedCategoryID = categoryObject.categoryID;
		$scope.columnDetails = angular.fromJson($scope.$parent.selectedCategory.fieldsInfo);
		$('#dropDownCategory').html($("#category-" + $scope.$parent.selectedCategoryID).html() + '<span class="caret"></span>');
		$scope.getAllMetricFromService($scope.sortMetricMap);

		$scope.$parent.selectedCategory.freqIntervalID.metric_Frequency = $scope.getfrequency();
	};

	$scope.getMetricData = function(response)
	{
		$(".loader").fadeOut("slow");
		if(response != undefined)
		{
			if(response.MdiCoreResp.success)
				$scope.showAlert("Metric data saved Successfully!!!","noError", "Completed");
			else
				$scope.showAlert(response.MdiCoreResp.message,"error");
		}
		$scope.getAllMetricValueFromService($scope.metricOperationInitailzation);
	};

	$scope.schoolYearChange = function(schoolYear)
	{
		$scope.$parent.selectedSchoolYear = schoolYear;
		$('#dropDownSchoolYear').html($("#schoolYear-" + $scope.$parent.selectedSchoolYear).html() + '<span class="caret"></span>');

		$scope.getMetricData();
	};

	$scope.frequencyChange = function(frequencyObject)
	{
		$scope.$parent.selectedFrequencyID = frequencyObject.frequencyID;
		$scope.$parent.selectedFrequency = frequencyObject;
		$('#dropDownFrequency').html($("#frequency-" + $scope.$parent.selectedFrequencyID).html() + '<span class="caret"></span>');

		$scope.getMetricData();
	};

	$scope.sortMetricMap = function()
	{
		$scope.$apply(function()
		{
			$scope.$parent.MetricMap = $scope.$parent.MetricMap.slice(0).sort(function(a, b)
			{
				return a.sequenceOrderValue - b.sequenceOrderValue;
			});
		});
		$(".loader").fadeOut("slow");
		$('#ulFrequency a:first').click();
	};

	$scope.getfrequency = function()
	{
		if($scope.$parent.selectedCategory.freqIntervalID == undefined)
			$scope.$parent.selectedCategory.freqIntervalID["metric_Frequency"] = [];
		else
		if(!($.isArray($scope.$parent.selectedCategory.freqIntervalID.metric_Frequency)))
			$scope.$parent.selectedCategory.freqIntervalID.metric_Frequency = [$scope.$parent.selectedCategory.freqIntervalID.metric_Frequency];

		$scope.$parent.selectedCategory.freqIntervalID.metric_Frequency = $scope.sortAccordingToOrderValue($scope.$parent.selectedCategory.freqIntervalID.metric_Frequency);

		return $scope.$parent.selectedCategory.freqIntervalID.metric_Frequency;
	};

	$scope.showInstruction = function(value)
	{
 		//$("#msgHeader").css( "background-color", "rgb(83, 84, 84)");
 		
  		$('#MessageBox').modal({
  			show: true,
  		});

		$("#modal-title-area").html("Instructions");
  		$("#modal-body-MessageBox").empty();
  		$("#modal-body-MessageBox").html(value);
	};

	$scope.saveMetricData = function()
	{
		$("small").remove(".validators");
		if($scope.hasError())
			return;
		
		var ajaxObj = {"categoryID":$scope.$parent.selectedCategoryID + "", "frequencyID":$scope.$parent.selectedFrequencyID + "", "yearValue":$scope.$parent.selectedSchoolYear+""};

		var dataArr = [];
		for(key in $scope.$parent.currentMetricData)
		{
			dataArr.push($scope.$parent.currentMetricData[key]);
		}
		ajaxObj["metricDataList"] = angular.toJson(dataArr);

		$scope.confirmationBox ("thisWillSaveMetricValues", angular.toJson(ajaxObj), "saveMetricData", $scope.getMetricData, "", "");
	};
	
	$scope.hasError = function()
	{
		var validationResult = false;
		var numericField = ["firstColumn", "secondColumn", "thirdNumericData", "fourNumericData", "fiveNumericData"];

		for(var metricId in $scope.$parent.currentMetricData)
		{
			for(var index = 0; index < numericField.length; index++)
			{
				var columnName = numericField[index];

				if($scope.columnDetails[columnName] == undefined)
					continue;

				if($scope.$parent.metricData[metricId].formula[columnName].metricVisibility == false || $scope.columnDetails[columnName].exists == false)
					continue;
				else
				{
					var min = $scope.$parent.metricData[metricId].formula[columnName].range.min;
					var max = $scope.$parent.metricData[metricId].formula[columnName].range.max;

					if(isNaN($scope.$parent.currentMetricData[metricId][columnName]) && $scope.$parent.currentMetricData[metricId][columnName] != "" && $scope.$parent.currentMetricData[metricId][columnName] != undefined)
					{
						validationResult = true;
						$("#" +metricId + "-" + columnName).parent().parent().append('<small class="validators">Value should be a number</small>');
						$("#" +metricId + "-" + columnName).parent()[0].scrollIntoView();
						continue;
					}

					if(min !== "")
					{
						if(parseFloat($scope.$parent.currentMetricData[metricId][columnName]) < min)
						{
							validationResult = true;
							$("#" +metricId + "-" + columnName).parent().parent().append('<small class="validators">Value should be greater than or equal to ' + min + '</small>');
							$("#" +metricId + "-" + columnName).parent()[0].scrollIntoView();
						}
					}
					if(max !== "")
					{
						if(parseFloat($scope.$parent.currentMetricData[metricId][columnName]) > max)
						{
							validationResult = true;
							$("#" +metricId + "-" + columnName).parent().parent().append('<small class="validators">Value should be less than or equal to ' + max + '</small>');
							$("#" +metricId + "-" + columnName).parent()[0].scrollIntoView();
						}
					}
				}
			}
		}

		return validationResult;
	};

	$scope.getAllFormFromService($scope.formSelector);

	$scope.metricOperationInitailzation = function()
	{
		$("small").remove(".validators");
		$("[data-toggle ='tooltip']").tooltip();

		$("input:checkbox").each(function()
	    {
	    	$(this).bind('click', function()
	    	{
	    		var checkboxname = $(this).attr("name");

	    		var values = [];
	    		$("input:checkbox[name = '"+checkboxname+"']:checked").each(function()
	    		{
	    			values.push($(this).attr("value"));
	    		});

	    		var metricID = checkboxname.split("-")[1];
	        	var columnKey = checkboxname.split("-")[0];

	  	       	$scope.$apply(function()
	  	       	{
	  	       		$scope.currentMetricData[metricID][columnKey] = values.join("~separate~");
	  	       	});
	    	});
	    });
		$scope.manageTheme();
		$scope.$apply();
		$(".loader").fadeOut("slow");
	};

	$scope.getReplaceValue = function(value)
	{
		if(value!=undefined)
			return value.replace(/~separate~/g, ", ");
		else
			return "";
	};

	$scope.getFormulaValue = function(metricID, key)
	{
		var formulaString = $scope.$parent.metricData[metricID].formula[key].formula.formulaWithId;

		var separators = ['~MUL~', '~ADD~', '~DIV~', '~MIN~', '~BS~', '~BE~'];
		var metricIDList = formulaString.split(new RegExp(separators.join('|'), 'g'));

		var nullCount = 0;
		for(var i = 0; i < metricIDList.length; i++)
		{
			if(metricIDList[i] in $scope.$parent.currentMetricData)
			{
				var value = "";
				if($scope.$parent.metricData[metricIDList[i]].formula["metricVisibility"] == false)
					value = null;
				else
				{
					value = ($scope.$parent.currentMetricData[metricIDList[i]][key]).toString().replace(/,/g,"");
					if(isNaN(value) || value == "")
						value = null;
				}
				if(value == null)
					nullCount++;
				formulaString = formulaString.replace(metricIDList[i],value);
			}
			else
				nullCount++;
		}
		formulaString = formulaString.replace(/~MUL~/g,"*").replace(/~ADD~/g,"+").replace(/~DIV~/g,"/").replace(/~MIN~/g,"-").replace(/~BS~/g,"(").replace(/~BE~/g,")");

		formulaString = formulaString.replace(/~/g,"");
		var resultantValue = eval(formulaString);

		if(nullCount == metricIDList.length)
			resultantValue = "";

		if($scope.$parent.currentMetricData[metricID] != undefined)
			$scope.$parent.currentMetricData[metricID][key] = resultantValue;

		return resultantValue;
	};

	$scope.downloadMetricDataPdf = function()
	{
		$(".loader").show();
		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "exportMetricDataPDF";
		paramData.data = angular.toJson({"categoryID":$scope.selectedCategoryID + "", "frequencyID":$scope.selectedFrequencyID + "", "yearValue":$scope.selectedSchoolYear+""});

		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, function(response)
		{
			$(".loader").fadeOut("slow");
			if(!response.MdiCoreResp.success)
			{
				$scope.showAlert("Error in downloading current data");
				return;
			}
			$scope.downloadFile(response.MdiCoreResp.params, $filter('splitSchoolYear')($scope.$parent.selectedSchoolYear) +"'s " + $scope.$parent.selectedForm.formLabel +"'s "+ $scope.$parent.selectedCategory.categoryName + "'s MetricData.pdf");
		});
	};

	$scope.downloadMetricAttachemntFile = function(metrticId)
	{
		$scope.showAlert("Not completed","error");
	};

	$scope.downloadMetricDataExcel = function()
	{
		$(".loader").show();
		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "downloadMetricDataExcel";
		paramData.data = angular.toJson({"categoryID":$scope.selectedCategoryID + "", "frequencyID":$scope.selectedFrequencyID + "", "yearValue":$scope.selectedSchoolYear+""});

		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, function(response)
		{
			$(".loader").fadeOut("slow");
			if(!response.MdiCoreResp.success)
			{
				$scope.showAlert("Error in downloading current data","error");
				return;
			}
			$scope.downloadFile(response.MdiCoreResp.params, $filter('splitSchoolYear')($scope.$parent.selectedSchoolYear) +"'s " + $scope.$parent.selectedForm.formLabel +"'s "+ $scope.$parent.selectedCategory.categoryName + "'s MetricData.xls");
		});
	};

	$scope.uploadMetricDataExcel = function()
	{
		$('#approvelStatusConfirmation').modal({
  			backdrop: 'static',
  			show: true,
  		});
  		$("#modal-body-approvalStatus").html('<span class="btn btn-default btn-file col-sm-12">  <input type="file" id = "uploadMetricTemplate"></span>');

  		$("#changeStatus").unbind( "click" );
  		$("#changeStatus").on('click',function()
  		{
  			var inputFiles = document.getElementById("uploadMetricTemplate").files;
  			
  			if(inputFiles == undefined || inputFiles.length == 0)
   		    	return;

  			var reader = new FileReader();
  			reader.onload = function(e) 
  			{
  				binaryString = e.target.result;
  				var base64String = binaryString;

  				$(".loader").show();
  				var paramData = angular.copy(kpiTrackerServiceObject);
  				paramData.serviceName = "importMetricDataExcel";
  				paramData.data = angular.toJson({"fileString" : base64String});

  				$scope.sdk.secureRequest($scope.reqiureUrl, paramData, $scope.getMetricData);
  			};
  			reader.readAsDataURL(inputFiles[0]);
  		});
	};

	$scope.convertIfNum = function(option,key)
	{
		var numericField = ["firstColumn", "secondColumn", "thirdNumericData", "fourNumericData", "fiveNumericData"];
		
		if(numericField.indexOf(key) > -1)
			return parseFloat(option);
		else
			return option;
	};
}]);