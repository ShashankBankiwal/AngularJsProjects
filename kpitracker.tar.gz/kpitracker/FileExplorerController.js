metricModule.controller( "FileExplorerController",["$scope", function($scope) 
{
	 $scope.dirStrBackup = {};
	 $scope.modal.newDir = false;
	 $scope.newDirName = "New folder";

	 $scope.selectedDir = {
		id: 0,
		isChildPresent: true,
		name: "Home",
		nodes: []
	 };
	 /**
	 * @function
	 * @description changes the mode to directory creation mode
	 * @author EID201
	 * */
	 $scope.goToCreateDirMode = function() {
		 $scope.newDirName ="";
		 $scope.modal.newDir = true;
	 };
	 
	 /**
	 * @function
	 * @description creates new directory in the specified directory
	 * @param { object } parentDir - the parent directory object
	 * @author EID201
	 * */
	 $scope.createNewDir = function(parentDir) {
		 var currentTime = new Date().toString(),
		 data = {
			 		"spacekey": $scope.userDetails.user.spaceKey,
			 		"token": $scope.userDetails.authToken,
					"position": "0",
					"type": "folder",
					"parentid": parentDir.id,
					"dashboardtype": "0",
					"id": "0",
					"imagename": "dashboard.png",
					"title": $scope.newDirName,
					"description": "Created from KPI tracker on " + currentTime,
					"file": ""
			};
		 
		$scope.sdk.secureRequest(req_url.home.uploaddashboard, data, function( data ) 
		{
			 var newlyCreatedDir = null, parentId = null;
			 if( data.trees.success) {
				 newlyCreatedDir = data.trees.tree;
				 parentId  = data.trees.tree.parentId.id;
				 $scope.dirStrBackup[ parentId ].push( {
					id: newlyCreatedDir.id,
					isChildPresent: false,
					name: newlyCreatedDir.title,
					nodes: [],
					parent: parentId
				 } );
				 
				 //console.log($scope.dirStrBackup[ parentId ])
				 //console.log(58)
				 $scope.dirList = $scope.dirStrBackup[ parentId ];
				 $scope.modal.newDir = false;
				 $scope.$apply();
			 }
			 else {
				 $scope.showAlert("Error in folder creation","error");
			 }
		 } );
	 };
	 
	 /**
	 * @function
	 * @description updates the selected directory for publishing dashboard
	 * @param { object } dir - the directory object
	 * @author EID201
	 * */
	 $scope.setSelectedDirToPublish = function( dir ) {
		 $scope.selectedFolderToPublish = {
			"id" : dir.id,
			"title": dir.name
		 };
		 $scope.modal.selectedDirToPublish = { 
			"id" : dir.id,
			"title": dir.name
		 };
	 };
	 
	 /**
	  * @function
	  * @description updates the directory list
	  * @author EID201
	  * */
	 $scope.loadPortalDirs = function() {
		 $scope.dirList = $scope.publishFolder;
		 if( $scope.dirList ) {
			 for( var i = 0; i < $scope.dirList.length; i++ ) 
			 {
				 $scope.dirList[ i ][ "parent" ] = 0;
			 };
			 $scope.dirStrBackup["dirList"] = [angular.copy($scope.selectedDir)];
			 $scope.dirStrBackup["0"] = angular.copy($scope.dirList);
			 $scope.setSelectedDirToPublish($scope.selectedDir);
		 }
		 $scope.$apply();
	 };
	 
	 /**
	  * @function
	  * @description updates the directory list with child directories
	  * @param { object } dir - the directory object
	  * @author EID201
	  * */
	 $scope.getChildDirs = function(dir)
	 {
		var data = {
				"spacekey": $scope.userDetails.user.spaceKey,
				"token": $scope.userDetails.authToken,
				"nodeid": dir.id
		};

		dir.nodes = [];
		if( $scope.dirStrBackup[dir.id]) {
			 //console.log($scope.dirStrBackup[ dir.id ])
			 //console.log(125)
			$scope.dirList = $scope.dirStrBackup[ dir.id ];
			$scope.selectedDir = dir;
			$scope.setSelectedDirToPublish( $scope.selectedDir );
		}
		else {
			$scope.sdk.secureRequest(req_url.home.documentlist, data, function(data) 
			{
				var childs = data.trees.treesList;
				if(!angular.isArray(childs))
					childs = [childs];
				for( var i = 0; i < childs.length; i++ ) {
					if( childs[ i ] != undefined && childs[ i ].type == "folder" ) {
						dir.isChildPresent = true;
						var n = {
							"name":"",
							"id":"",
							"nodes":[]
						};
						n.id = childs[ i ].id;
						n.name = childs[ i ].title;
						n.nodes = [];
						n.isChildPresent = false;
						n.parent = dir.id;
						dir.nodes.push( n );
					}
				}
				 //console.log( dir.nodes)
				// console.log(151)
				$scope.dirList = dir.nodes;
				$scope.selectedDir = dir;
				$scope.setSelectedDirToPublish($scope.selectedDir);
				$scope.dirStrBackup[ dir.id ] = angular.copy($scope.dirList);
				$scope.dirStrBackup["dirList"].push(dir);
				$scope.$apply();
			}, $scope.secureRequestErrorHandler );
		}
	 };
	 
	 /**
	  * @function
	  * @description returns the directory object by directory id
	  * @param { string } dirId - the directory id
	  * @author EID201
	  * */
	 $scope.getDirById = function( dirId ) 
	 {
		 var dir = {};
		 angular.forEach($scope.dirStrBackup["dirList"], function(value, key) 
		 {
			 if(value.id == dirId)
			 {
				 dir = value;
				 return false;
			 }
		 });
		 return dir;
	 };
	 
	 /**
	  * @function
	  * @description update the directory list to the parent directory
	  * @param { object } dir - the directory object
	  * @author EID201
	  * */
	 $scope.getParentDir = function( dir ) {
		 if( $scope.modal.newDir ) {
			 $scope.modal.newDir = false;
			 return;
		 }
		 else if( dir && dir.id != 0 ) {
			 $scope.dirList = $scope.dirStrBackup[ dir.parent ];
			 $scope.selectedDir = $scope.getDirById( dir.parent );
			 $scope.setSelectedDirToPublish( $scope.selectedDir );
		 }
	 };
	 
	 /**
	  * @function
	  * @description update the directory list to the root directory
	  * @param { object } dir - the directory object
	  * @author EID201
	  * */
	 $scope.goToRootDir = function() 
	 {
		 $scope.dirList = $scope.dirStrBackup[0];
		 $scope.selectedDir = $scope.getDirById(0);
		 $scope.setSelectedDirToPublish($scope.selectedDir);
	 };

	 $scope.loadFolderStructure = function() 
	 {
		$scope.publishFolder = [] ;

		var data = {
				"spacekey": $scope.userDetails.user.spaceKey,
				"token": $scope.userDetails.authToken,
				"nodeid": 0
		};

		$scope.sdk.secureRequest(req_url.home.documentlist, data, function(data) 
		{
			var rootFolder = data.trees.treesList;
			for(var i=0 ;i<rootFolder.length ; i++)
			{
				var nodeJson = {"name":"" , "id":"" , "nodes":[]};
				nodeJson.id = rootFolder[i].id;
				nodeJson.name = rootFolder[i].title;
				nodeJson.nodes = [];
				nodeJson.isChildPresent = false;
				$scope.publishFolder.push(nodeJson);
				//$scope.loadChildFolder(nodeJson);
			}

			$scope.loadPortalDirs();
		}, $scope.secureRequestErrorHandler );
	 };

	 $scope.loadFolderStructure();
	 //$scope.getChildDirs($scope.selectedDir);
}]);