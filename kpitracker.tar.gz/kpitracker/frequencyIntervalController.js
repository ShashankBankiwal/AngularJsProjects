metricModule.controller('FrequencyController',['$scope', function( $scope )
{	
	$(".nav").find(".active").removeClass("active");
	$(".nav > li[value='0']").addClass("active");

	$scope.currentFrequencyInstance = angular.copy(frequencyIntervalObject);

	$scope.sortableOptions = {    
	   stop: function(e, ui) 
	   {
		   var index = 0;
		   $scope.currentFrequencyInstance["metric_Frequency"].map(function(i)
		   {
			   i.orderValue = index;
			   index++;
		   });
	   }
	};
	
	$scope.getAllFrequencyData = function(response)
	{
		if(angular.isDefined(response))
		{
			if(response.MdiCoreResp.success)
				$scope.showAlert(response.MdiCoreResp.message,"noError");
			else
				$scope.showAlert(response.MdiCoreResp.message,"error");
		}
		$scope.getAllFrequencyFromService($scope.clearFrequencyData);
	};

	$scope.editFrequencyInterval = function(obj)
	{
		$("small").remove(".validators");
		
		var tempObj = angular.copy(obj);
		if(tempObj["metric_Frequency"] == undefined)
			tempObj["metric_Frequency"] = [];
		else
		if(angular.isArray(tempObj["metric_Frequency"]))
			tempObj["metric_Frequency"] = $scope.sortAccordingToOrderValue(tempObj["metric_Frequency"]);
		else
			tempObj["metric_Frequency"] = [tempObj["metric_Frequency"]];

		$scope.currentFrequencyInstance = tempObj;
	};

	$scope.deleteFrequencyInterval = function(frequencyIntervalObject)
	{
		$scope.confirmationBox ("thisWillDeleteFrequencyInterval", angular.toJson({"freqIntervalID":""+frequencyIntervalObject.freqIntervalID}), "deleteFrequencyInterval", $scope.getAllFrequencyData, "", "");
	};
	
	$scope.deleteFrequency = function(index)
	{
		$scope.currentFrequencyInstance.metric_Frequency.splice(index,1);
	};

	$scope.saveFrequencyInterval = function()
	{
		$("small").remove(".validators");
		if($scope.hasError())
			return;

		$scope.currentFrequencyInstance["spaceKey"] = $scope.userDetails.user.spaceKey;
	    $scope.confirmationBox ("thisWillSaveFrequencyInterval", angular.toJson($scope.currentFrequencyInstance), "saveFrequencyInterval", $scope.getAllFrequencyData, "", "");
	};

	$scope.addFrequency = function(obj)
	{
		if($("#frequencyInput").val() == "")
			return;
		var freq = angular.copy(frequencyObject);
		freq["spaceKey"] = $scope.userDetails.user.spaceKey;
		freq["frequencyName"] = $("#frequencyInput").val();
		freq["orderValue"] = $('#frequencyTableBodyContainer tr').length;
		$scope.currentFrequencyInstance["metric_Frequency"].splice(0, 0, freq);

		$("#frequencyInput").val("");
	};

	$scope.clearFrequencyData = function()
	{	
		$scope.manageTheme();
		$scope.$apply(function()
		{
			$scope.currentFrequencyInstance = angular.copy(frequencyIntervalObject);
			$("small").remove(".validators");
			$(".loader").fadeOut("slow");
		});
	};

	$scope.clearFrequencyDataOnClick = function()
	{
		$scope.currentFrequencyInstance = angular.copy(frequencyIntervalObject);
		$("small").remove(".validators");
	};

	$scope.hasError = function()
	{
		var validationResult = false;

		if($scope.currentFrequencyInstance.metric_Frequency.length == 0)
		{
			validationResult = true;
			$("#frequencyInput").parent().append('<small class="validators">Please fill aleast one frequency</small>');
		}

		if($scope.currentFrequencyInstance.freqIntervalName == "")
		{
			validationResult = true;
			$("#frequencyIntervalName").parent().append('<small class="validators">Please fill frequency interval name</small>');
		}
		return validationResult;
	};

	$scope.getAllFrequencyData();
}]);
