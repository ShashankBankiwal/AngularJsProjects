metricModule.controller('MetricController',['$scope', '$compile', function( $scope, $compile )
{
	$scope.$parent.MetricMap = [];
  	$scope.$parent.parentChildMap = {};
  	$scope.$parent.metricData = {};
  	$scope.$parent.currentMetricData = {};
  	$scope.$parent.previousMetricData = {};
 
	$(".nav").find(".active").removeClass("active");
	$(".nav > li[value='3']").addClass("active");

	$scope.numericField = ["firstColumn", "secondColumn", "thirdNumericData", "fourNumericData", "fiveNumericData"];

	$scope.columnDetails = {};

	$scope.sortableOptions = {
		animation: 150,
		update: function (e, event)
		{
		    var metricId = event.item.attr("id").split("-")[1];
		    var newparentID = $("#"+event.item.attr("id")).parent().attr('id').split("-")[1];

			metric = $scope.metricData[metricId];
			metric.parentID = newparentID;

			var arr = [];
			var value = $scope.createOrderList(newparentID, arr);

  			$(".loader").show();
  			var paramData = angular.copy(kpiTrackerServiceObject);
  			paramData.serviceName = "orderMetric";
  			paramData.data = angular.toJson(value);
			$scope.sdk.secureRequest($scope.reqiureUrl, paramData, $scope.getAllMetricData);
		},
	};

	$scope.createOrderList = function(newparentID, arr)
	{
		var childrens = $("#metricul-" + newparentID).children("li");
		for(var i = 0 ; i < childrens.length ; i++)
		{
			var id = $(childrens[i]).attr('id').split("-")[1];

			metric = $scope.metricData[id];
			metric.formula = angular.toJson($scope.metricData[id].formula);
			metric.orderValue = i;
			arr.push(metric);
		}
		return arr;
	};

	$scope.setOrder = function()
	{
		var arr = [];
		var childrens = $("#metricul-0").find("li");
		for(var i = 0 ; i < childrens.length ; i++)
		{
			var id = $(childrens[i]).attr('id').split("-")[1];

			metric = $scope.metricData[id];
			metric.formula = angular.toJson($scope.metricData[id].formula);
			metric.sequenceOrderValue = i;
			arr.push(metric);
		}
		
		$(".loader").show();
		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "orderMetric";
		paramData.data = angular.toJson(arr);
		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, $scope.getAllMetricData);
	};

	$scope.getAllMetricData = function(response)
	{
		if(response != undefined)
		{
			if(response.MdiCoreResp.success)
				$scope.showAlert(response.MdiCoreResp.message,"noError");
			else
				$scope.showAlert(response.MdiCoreResp.message,"error");
		}
		$scope.getAllMetricFromService($scope.clearMetricData);
	};

	$scope.firstFormSelected = function()
	{
		$(".loader").fadeOut("slow");
		$('#ulForm a:first').click();
	};

	$scope.formChange = function(formObject)
	{
		$scope.manageTheme();
		$scope.$parent.selectedForm = formObject;
		$scope.$parent.selectedFormID = formObject.formID;
		$('#dropDownForm').html($("#form-" + $scope.$parent.selectedFormID).html() + '<span class="caret"></span>');
		$scope.getAllCategoryFromService($scope.firstCategorySelected);
	};

	$scope.firstCategorySelected = function()
	{
		$(".loader").fadeOut("slow");
		$('#ulCategory a:first').click();
		$scope.$apply(function() 
		{
			if($scope.$parent.CategoryMap.length == 0)
				$scope.columnDetails = {};
		});
	};

	$scope.categoryChange = function(categoryObject)
	{
		$scope.$parent.selectedCategory = categoryObject;
		$scope.$parent.selectedCategoryID = categoryObject.categoryID;
		$scope.columnDetails = angular.fromJson($scope.$parent.selectedCategory.fieldsInfo);
		$('#dropDownCategory').html($("#category-" + $scope.$parent.selectedCategoryID).html() + '<span class="caret"></span>');
		$scope.currentMetricInstance = angular.copy(metricObject);
		$scope.getAllMetricData();
	};

	$scope.getSortedMetricID = function(arr)
	{
		if(arr == undefined)
			return [];

		var sortedMetric = arr.sort(function(a, b)
		{
			return $scope.metricData[a].orderValue - $scope.metricData[b].orderValue;
		});

		return sortedMetric;
	};

	$scope.editMetric = function(MetricObj)
	{
		$("small").remove(".validators");
		$scope.currentMetricInstance = angular.copy(MetricObj);
		$scope.currentMetricInstance.categoryID = {"categoryID" : $scope.$parent.selectedCategory.categoryID};
	};

	$scope.deleteMetricFamily = function(parentID)
	{
		var ArrayOfMetric = [];
		ArrayOfMetric = $scope.getAllParentMetricChilds(parentID,ArrayOfMetric);
		ArrayOfMetric.push(parentID);
		var params = {"metricIDs":ArrayOfMetric};

		$scope.confirmationBox ("thisWillDeleteMetricAndItsChild", angular.toJson(params), "deleteMetric", $scope.getAllMetricData, "", "");
	};

	$scope.getAllParentMetricChilds = function(parentID,ArrayOfMetric)
	{
		if($scope.parentChildMap[parentID] == undefined)
			return ArrayOfMetric;

		for(var i = 0 ; i < $scope.parentChildMap[parentID].length ; i++)
		{
			ArrayOfMetric.push($scope.parentChildMap[parentID][i]+"");
			$scope.getAllParentMetricChilds($scope.parentChildMap[parentID][i],ArrayOfMetric);
		}
		return ArrayOfMetric;
	};

	$scope.saveMetric = function()
	{
		$("small").remove(".validators");
		if($scope.hasError())
			return;

		var copyofcurrentMetricInstance = angular.copy($scope.currentMetricInstance);
        copyofcurrentMetricInstance.formula = angular.toJson(copyofcurrentMetricInstance.formula);

	    $scope.confirmationBox ("thisWillSaveMetric", angular.toJson(copyofcurrentMetricInstance), "saveMetric", $scope.getAllMetricData, "", "");
	};

	$scope.createChildMetric = function(parentId)
	{
		$("small").remove(".validators");
		$scope.currentMetricInstance = angular.copy(metricObject);
		$scope.currentMetricInstance.categoryID = {"categoryID" : $scope.$parent.selectedCategory.categoryID};

		if($scope.parentChildMap[parentId+""] == undefined)
		{
			$scope.currentMetricInstance.orderValue = 0;
		}
		else
			$scope.currentMetricInstance.orderValue = $scope.parentChildMap[parentId].length;

		$scope.currentMetricInstance.parentID = parentId+"";
		$scope.currentMetricInstance.spaceKey = $scope.userDetails.user.spaceKey;
	};

	$scope.clearMetricData = function()
	{
		$scope.manageTheme();
		$scope.$apply(function() 
		{
			$("small").remove(".validators");
			$scope.currentMetricInstance = angular.copy(metricObject);
			$scope.currentMetricInstance.categoryID = {"categoryID" : $scope.$parent.selectedCategory.categoryID};
			$scope.currentMetricInstance.orderValue = $scope.parentChildMap["0"].length;
			$scope.currentMetricInstance.spaceKey = $scope.userDetails.user.spaceKey;
			$(".loader").fadeOut("slow");
		});
	};
	
	$scope.clearMetricDataOnClick = function()
	{
		$("small").remove(".validators");
		$scope.currentMetricInstance = angular.copy(metricObject);
		$scope.currentMetricInstance.categoryID = {"categoryID" : $scope.$parent.selectedCategory.categoryID};
		$scope.currentMetricInstance.orderValue = $scope.parentChildMap["0"].length;
		$scope.currentMetricInstance.spaceKey = $scope.userDetails.user.spaceKey;
	};
	
	$scope.hasError = function()
	{
		var validationResult = false;
		if($scope.currentMetricInstance.metricName == "")
		{
			validationResult = true;
			$("#metricNameChild").parent().append('<small class="validators">Please fill metric name</small>');
		}
		return validationResult;
	};

	$scope.updateformulaForSelect = function(colName,elementType)
	{
		var elementValue = $("#" + colName + elementType).val();
		var elementText = $("#" + colName + elementType + " option:selected").text();

		$scope.currentMetricInstance.formula[colName].formula.formulaWithName += elementText;
		$scope.currentMetricInstance.formula[colName].formula.formulaWithId += elementValue;

		$("#" + colName + elementType).val("");
		$scope.columnDetails[colName].formula[elementType] = "";
	};

	$scope.updateformulaForNumber = function(colName)
	{
		var elementValue = $("#" + colName + "Input").val();

		$scope.currentMetricInstance.formula[colName].formula.formulaWithName += elementValue;
		$scope.currentMetricInstance.formula[colName].formula.formulaWithId += elementValue;

		$("#" + colName + "Input").val("");
		$scope.columnDetails[colName].formula.sign = "";
	};

	$scope.clearformula = function(colName)
	{
		$scope.currentMetricInstance.formula[colName].formula.formulaWithName = "";
		$scope.currentMetricInstance.formula[colName].formula.formulaWithId = "";
	};
	
	$scope.downloadMetricTemplete = function()
	{
		$(".loader").show();
		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "downloadMetricListExcel";
		paramData.data = angular.toJson({"categoryID" : $scope.$parent.selectedCategoryID + ""});
		
		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, function(response)
		{
			$(".loader").fadeOut("slow");
			if(!response.MdiCoreResp.success)
			{
				$scope.showAlert("Error in downloading current data","error");
				return;
			}
			$scope.downloadFile(response.MdiCoreResp.params, $scope.$parent.selectedCategory.categoryName + "'s MetricList.xls");
		});
	};

	$scope.uploadMetricTemplete = function()
	{
		$('#approvelStatusConfirmation').modal({
  			backdrop: 'static',
  			show: true,
  		});
  		$("#modal-body-approvalStatus").html('<span class="btn btn-default btn-file col-sm-12">  <input type="file" id = "uploadMetricTemplate"></span>');
  		
  		$("#changeStatus").unbind( "click" );
  		$("#changeStatus").on('click',function()
  		{
  			var inputFiles = document.getElementById("uploadMetricTemplate").files;
  			
  			if(inputFiles == undefined || inputFiles.length == 0)
   		    	return;
  	
  			var reader = new FileReader();
  			reader.onload = function(e) 
  			{
  				binaryString = e.target.result;
  				var base64String = binaryString;

  				$(".loader").show();
  				var paramData = angular.copy(kpiTrackerServiceObject);
  				paramData.serviceName = "readMetricListExcelFile";
  				paramData.data = angular.toJson({"fileString" : base64String});
  				
  				$scope.sdk.secureRequest($scope.reqiureUrl, paramData, $scope.getAllMetricData);
  			};
  			reader.readAsDataURL(inputFiles[0]);
  		});
	};

	$scope.getAllFormFromService($scope.firstFormSelected);
	
	$scope.currentMetricInstance = angular.copy(metricObject);
}]);