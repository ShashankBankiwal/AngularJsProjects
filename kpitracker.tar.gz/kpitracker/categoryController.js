metricModule.controller('CategoryController',['$scope', function( $scope )
{
	$(".nav").find(".active").removeClass("active");
	$(".nav > li[value='2']").addClass("active");

	$scope.numericField = ["firstColumn", "secondColumn", "thirdNumericData", "fourNumericData", "fiveNumericData"];
	$scope.textField = ["thirdColumn", "secondTextData", "thirdTextData"];
	$scope.detail_Component = ["detail_Component"];

	$scope.getAllCategoryData = function(response)
	{
		if(response != undefined)
		{
			if(response.MdiCoreResp.success == true)
				$scope.showAlert(response.MdiCoreResp.message,"noError");
			else
				$scope.showAlert(response.MdiCoreResp.message,"error");
		}
		$scope.getAllCategoryFromService($scope.clearCategoryData);
	};

	$scope.firstFormSelected = function()
	{
		$('#ulForm a:first').click();
	};

	$scope.formChange = function(formObject)
	{
		$scope.$parent.selectedForm = formObject;
		$scope.$parent.selectedFormID = formObject.formID;
		$('#dropDownForm').html($("#form-" + $scope.$parent.selectedFormID).html() + '<span class="caret"></span>');
		$scope.getAllCategoryData();
	};

	$scope.editCategory = function(catObj)
	{
		$scope.currentCategoryInstance = angular.copy(catObj);
		$scope.currentCategoryInstance.fieldsInfo = JSON.parse(catObj["fieldsInfo"]);
		$scope.currentCategoryInstance.freqIntervalID = {"freqIntervalID" : catObj["freqIntervalID"].freqIntervalID};
		$("small").remove(".validators");
	};

	$scope.deleteCategory = function(catObj)
	{
	    $scope.confirmationBox ("thisWillDeleteCategory", angular.toJson({"categoryID":catObj.categoryID +""}), "deleteCategory", $scope.getAllCategoryData, "", "");
	};

	$scope.orderCategory = function()
	{
		$("small").remove(".validators");

		var catCopyArray = [];
		$.each($scope.CategoryMap, function(key, value)
		{
			catCopyArray[key] = angular.copy(value);
			catCopyArray[key].orderValue = key;

			if(!(angular.isArray(catCopyArray[key].freqIntervalID.metric_Frequency)))
				catCopyArray[key].freqIntervalID.metric_Frequency = [value.freqIntervalID.metric_Frequency];
		});

	    $scope.confirmationBox ("thisWillOrderCategoryList", angular.toJson(catCopyArray), "orderCategory", $scope.getAllCategoryData, "", "");
	};

	$scope.saveCategory = function()
	{
		$("small").remove(".validators");
		if($scope.hasError())
			return;
		var copyOfcurrentCategoryInstance = angular.copy($scope.currentCategoryInstance);
		try
		{
			copyOfcurrentCategoryInstance.freqIntervalID = JSON.parse(copyOfcurrentCategoryInstance.freqIntervalID);
        }
        catch (e)
        {
        	console.log("did not receive a valid Json: " + e);
        }

        copyOfcurrentCategoryInstance.fieldsInfo = angular.toJson(copyOfcurrentCategoryInstance.fieldsInfo);

//        if(!($.isArray($scope.copyOfcurrentCategoryInstance.freqIntervalID.metric_Frequency)))
//			$scope.copyOfcurrentCategoryInstance.freqIntervalID.metric_Frequency = [$scope.copyOfcurrentCategoryInstance.freqIntervalID.metric_Frequency];

		$scope.confirmationBox ("thisWillSaveCategory", angular.toJson(copyOfcurrentCategoryInstance), "saveCategory", $scope.getAllCategoryData, "", "");
	};

	$scope.clearCategoryData = function()
	{
		$scope.manageTheme();
		$scope.$apply(function() 
		{
			$("small").remove(".validators");
			$scope.currentCategoryInstance = angular.copy(categoryObject);
			$scope.currentCategoryInstance.orderValue = $scope.CategoryMap.length;
			$scope.currentCategoryInstance.formID = $scope.$parent.selectedForm;
			$scope.currentCategoryInstance.spaceKey = $scope.userDetails.user.spaceKey;
			$(".loader").fadeOut("slow");
		});
	};
	
	$scope.clearCategoryDataOnClick = function()
	{
		$("small").remove(".validators");
		$scope.currentCategoryInstance = angular.copy(categoryObject);
		$scope.currentCategoryInstance.orderValue = $scope.CategoryMap.length;
		$scope.currentCategoryInstance.formID = $scope.$parent.selectedForm;
		$scope.currentCategoryInstance.spaceKey = $scope.userDetails.user.spaceKey;
	};

	$scope.hasError = function()
	{
		var validationResult = false;
		if($scope.currentCategoryInstance.categoryName == "")
		{
			validationResult = true;
			$("#categoryName").parent().append('<small class="validators">Please fill Category name</small>');
		}

		if($scope.currentCategoryInstance.freqIntervalID == "")
		{
			validationResult = true;
			$("#categoryFrequency").parent().append('<small class="validators">Please select frequency interval</small>');
		}
		return validationResult;
	};

	$scope.getAllFrequencyFromService(angular.noop);
	
	$scope.getAllFormFromService($scope.firstFormSelected);
	
	$scope.currentCategoryInstance = angular.copy(categoryObject);
}]);