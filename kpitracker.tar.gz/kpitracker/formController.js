metricModule.controller('FormController',['$scope', function( $scope )
{
	$(".nav").find(".active").removeClass("active");
	$(".nav > li[value='1']").addClass("active");

	$scope.modal = {};
	$scope.publishDetails = {};
	$scope.publishFolder = [] ;

	$scope.secureRequestErrorHandler=function(jqXHR, exception)
	{
		if (jqXHR.status === 0) {
			ServiceFactory.closeAllNotifications();
			clearTimeout( $scope.timeout );
			$.unblockUI();
			$('#sessionWarning').modal('show');
		}
	};

	$scope.publishForm = function(formObject)
	{
		$scope.publishDetails["form"] = angular.copy(formObject);
		$("#publichModalDialog").modal("show");
	};
	
	$scope.publishToPortal = function()
	{
		var data = {
				"spacekey": $scope.userDetails.user.spaceKey,
				"token": $scope.userDetails.authToken,
				"parentid":  $scope.modal.selectedDirToPublish.id,
				"type" : "file",
				"dashboardtype" : 20,
				"id" : 0,
				"imagename" : "form.png",
				"treeRel": $scope.publishDetails.form.formID,
				"description" : $scope.publishDetails.formDescription,
				"file" : "",
				"title" : $scope.publishDetails.form.formLabel,
				"position":0
		};
		
		$scope.sdk.secureRequest(req_url.home.uploaddashboard, data, function(response)
		{
			if(response.trees.success)
				$scope.showAlert("Form published successfully");
		});
	};

	$scope.getAllFormData = function(response)
	{
		if(response != undefined)
		{
			if(response.MdiCoreResp.success)
				$scope.showAlert(response.MdiCoreResp.message,"noError");
			else
				$scope.showAlert(response.MdiCoreResp.message,"error");
		}
		$scope.getAllFormFromService($scope.clearFormData);
	};

	$scope.editForm = function(formObject)
	{
		$("small").remove(".validators");
		$scope.currentFormInstance =  angular.copy(formObject);
	};

	$scope.deleteForm = function(formObject)
	{
		$scope.confirmationBox ("thisWillDeleteForm", angular.toJson({"formID":""+formObject.formID}), "deleteForm", $scope.getAllFormData, "", "");
	};

	$scope.saveFormInterval = function()
	{
		$("small").remove(".validators");
		if($scope.hasError())
			return;

		$scope.currentFormInstance["spaceKey"] = $scope.userDetails.user.spaceKey;
	    $scope.confirmationBox ("thisWillSaveForm", angular.toJson($scope.currentFormInstance), "saveForm", $scope.getAllFormData, "", "");
	};

	$scope.clearFormData = function()
	{
		$scope.manageTheme();
		$scope.$apply(function() 
		{
			$("small").remove(".validators");
			$scope.currentFormInstance = angular.copy(formObject);
			$scope.currentFormInstance["orderValue"] = $scope.FormMap.length;
		});
		$(".loader").fadeOut("slow");
	};

	$scope.clearFormDataOnClick = function()
	{
		$("small").remove(".validators");
		$scope.currentFormInstance = angular.copy(formObject);
		$scope.currentFormInstance["orderValue"] = $scope.FormMap.length;
	};

	$scope.hasError = function()
	{
		var validationResult = false;
		if($scope.currentFormInstance.formLabel == "")
		{
			validationResult = true;
			$("#formName").parent().append('<small class="validators">Please fill form label</small>');
		}

		if($scope.currentFormInstance.formInstructions == "")
		{
			validationResult = true;
			$("#formInstructions").parent().append('<small class="validators">Please fill form Instruction</small>');
		}
		return validationResult;
	};

	$scope.currentFormInstance = angular.copy(formObject);//$scope.clearFormData();
	$scope.getAllFormData();
}]);