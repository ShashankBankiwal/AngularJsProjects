var metricModule = angular.module('metricDataInputApp',['ngRoute','ui.sortable','ui.date']);

metricModule.config(['$routeProvider', function($routeProvider)
{
	$routeProvider.
		when('/frequency', {
			templateUrl: '../../views/kpitracker/FrequencyContent.html',
			controller: 'FrequencyController'
	   }).
	   when('/form', {
		   	templateUrl: '../../views/kpitracker/FormContent.html',
		   	controller: 'FormController'
	   }).
	   when('/category', {
		   	templateUrl: '../../views/kpitracker/CategoryContent.html',
		   	controller: 'CategoryController'
	   }).
	   when('/metric', {
		   	templateUrl: '../../views/kpitracker/MetricContent.html',
		   	controller: 'MetricController'
	   }).
	   when('/metricDataUpload', {
		   	templateUrl: '../../views/kpitracker/metricDataUpload.html',
		   	controller: 'MetricDataController'
	   }).
	   otherwise({
		   redirectTo: '/metricDataUpload'
	   });
}]);

metricModule.controller('MainController',['$scope', '$location', function( $scope ,$location)
{
	$scope.CategoryMap = [];
  	$scope.MetricMap = [];
  	$scope.FormMap = [];
  	$scope.FrequencyMap = [];
	$scope.currentMetricMap = [];
  	$scope.previousMetricMap = [];

  	$scope.selectedFormID = 0;
  	$scope.selectedCategoryID = 0;
  	$scope.selectedFrequencyID = 0;
  	$scope.selectedSchoolYear = new Date().getFullYear();

  	$scope.parentChildMap = {};
  	$scope.metricData = {};

  	$scope.currentMetricData = {};
  	$scope.previousMetricData = {};

  	$scope.selectedForm =  {};
  	$scope.selectedCategory = {};
  	$scope.selectedFrequency = {};
  	
  	$scope.userDetails = {};
   	$scope.themeDetails = {};
   	$scope.sdk = {};
   	
   	try {
   		$scope.userDetails = BIZVIZ.SDK.getAuthInfo();
   	   	$scope.themeDetails = $.jStorage.get("preferenceObject");//$scope.userDetails.preference.themeID;
   	   	$scope.sdk = BIZVIZ.SDK;
   	   	pathforpopHtml = "views/kpitracker/popUpTemplete.html";
   	}
   	catch(err) {
   		$scope.userDetails = parent.BIZVIZ.SDK.getAuthInfo();
   	   	$scope.themeDetails = parent.$.jStorage.get("preferenceObject");//$scope.userDetails.preference.themeID;
   	   	$scope.sdk = parent.BIZVIZ.SDK;
   	   	pathforpopHtml = "popUpTemplete.html";
   	}
  	$scope.reqiureUrl = req_url.otms.ipluginService;

  	$scope.confirmationBox = function (boxContent, ajaxObj, servicename, callbackMethod, notCallbackMthod, msgId)
  	{
  		$('#approvelStatusConfirmation').modal({
  			backdrop: 'static',
  			show: true,
  		});
  		$("#modal-title-area").html('<label data-res = "kpiTracker.confirmation">Confirmation</label>');
  		$("#modal-body-approvalStatus").empty();
  		$("#modal-body-approvalStatus").append('<div data-res = "kpiTracker.'+boxContent+'">' + kpiConfirmationMsg[boxContent] + '</div>');

  		$("#changeStatus").unbind( "click" );
  		$("#changeStatus").on('click',function()
  		{
  			$(".loader").show();
  			var paramData = angular.copy(kpiTrackerServiceObject);
  			paramData.serviceName = servicename;
  			paramData.data = ajaxObj;
 
  			$scope.sdk.secureRequest($scope.reqiureUrl, paramData, callbackMethod);
  		});

  		$("#changeStatusCancel").unbind( "click" );
  		$("#changeStatusCancel").on('click',function()
  		{
  			angular.noop();
  		});
 // 	i18n.changeLanguage();
  	};

  	$scope.manageTheme = function()
  	{
  		$(".btn-color-theme").css( "background", $scope.themeDetails.headerBGColor );
  		$(".btn-color-theme").hover(function(){
  		    $(this).css("background-color", $scope.themeDetails.navBarBGColor);
  		    }, function(){
  		    $(this).css("background-color", $scope.themeDetails.headerBGColor);
  		});

  		$(".mdiIcon").css("color", $scope.themeDetails.headerBGColor);
  		$(".mdiIcon").hover(function(){
  		    $(this).css("color", $scope.themeDetails.navBarBGColor);
  		    }, function(){
  		    $(this).css("color", $scope.themeDetails.headerBGColor);
  		});

  		$("thead").css("background", $scope.themeDetails.headerBGColor);
  		$(".mdi-header").css("background", $scope.themeDetails.navBarBGColor);
  		$(".thememanage").css("background", $scope.themeDetails.navBarBGColor);
  		$(".dropdown-menu.custom-menu").css("background", $scope.themeDetails.contextMenuBGColor);
  		$(".dropdown-menu.custom-menu").css("color", $scope.themeDetails.contextMenuTextAndIconColor);
  		$(".modal-header").css("background", $scope.themeDetails.headerBGColor);
  	};

  	$scope.sortAccordingToOrderValue = function(obj)
  	{
  		var sortedArray = obj.sort(function(a, b)
  		{
  			return a.orderValue - b.orderValue;
  		});
  		return sortedArray;
  	};

  	$scope.getAllFrequencyFromService = function(callbackMethod)
  	{
  		$(".loader").show();
		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "getAllFrequecnyInterval";
		
		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, function(response, status)
  		{
  			var frequencyresponse = response.MdiCoreResp;

			if(!frequencyresponse.success)
		    	$scope.showAlert(frequencyresponse.message);

			var frequencyDetails = frequencyresponse.metricFrequencyIntervalList;

			$scope.$apply(function()
			{
				if(!angular.isDefined(frequencyDetails))
					$scope.FrequencyMap = [];
				else
				if(angular.isArray(frequencyDetails))
					$scope.FrequencyMap = frequencyDetails;
				else
					$scope.FrequencyMap = [frequencyDetails];
			});

			callbackMethod();
  		});
  	};

  	$scope.getAllFormFromService = function(callbackMethod)
  	{
  		$(".loader").show();
  		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "getAllForm";

		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, function(response)
  		{
  			var formresponse = response.MdiCoreResp;

			if(!formresponse.success)
		    	$scope.showAlert(formresponse.message);

			var formDetails = formresponse.metricFormList;

			$scope.$apply(function()
			{
				if(!angular.isDefined(formDetails))
					$scope.FormMap = [];
				else
				if(angular.isArray(formDetails))
					$scope.FormMap = formDetails;
				else
					$scope.FormMap = [formDetails];

				if($scope.FormMap.length > 0)
				{
					$scope.selectedForm = $scope.FormMap[0];
					$scope.selectedFormID = $scope.FormMap[0].formID;
				}
				else
				{
					$(".loader").fadeOut("slow");
					$location.path('/form');
					return;
				}
			});

			callbackMethod();
  		});
  	};

  	$scope.getAllCategoryFromService = function(callbackMethod)
  	{
  		$(".loader").show();
  		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "getAllCategoryByForm";
		paramData.data = angular.toJson({"formID" : $scope.selectedFormID + ""});

		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, function(response)
  		{
			var categoryResponse = response.MdiCoreResp;

			if(!categoryResponse.success)
		    	$scope.showAlert(categoryResponse.message);

			var categoryDetails = categoryResponse.metricCategoryList ;

			$scope.$apply(function()
			{
				if(!angular.isDefined(categoryDetails))
					$scope.CategoryMap = [];
				else
				if(angular.isArray(categoryDetails))
					$scope.CategoryMap = categoryDetails;
				else
					$scope.CategoryMap = [categoryDetails];

				if($scope.CategoryMap.length > 0)
				{
					$scope.CategoryMap = $scope.sortAccordingToOrderValue($scope.CategoryMap);
					$scope.selectedCategory = $scope.CategoryMap[0];
					$scope.selectedCategoryID = $scope.CategoryMap[0].categoryID;
				}
				else
				{
					$scope.CategoryMap = [];
					$scope.MetricMap = [];
					$scope.parentChildMap = {};
					$scope.metricData = {};
					$("#dropDownCategory").html("No category selected<span class='caret'></span>");
				}
			});

			callbackMethod();
  		}); 			
  	};

  	$scope.getAllMetricFromService = function(callbackMethod)
  	{
  		$(".loader").show();
  		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "getAllMetric";
		paramData.data = angular.toJson({"categoryID":$scope.selectedCategoryID + ""});

		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, function(response)
  		{
  			var metricResponse = response.MdiCoreResp;

  			if(!metricResponse.success)
		    	$scope.showAlert(metricResponse.message);

  			var metricData = metricResponse.metricList;

			$scope.$apply(function()
			{
				if(!angular.isDefined(metricData))
					$scope.MetricMap = [];
				else
				if(angular.isArray(metricData))
					$scope.MetricMap = metricData;
				else
					$scope.MetricMap = [metricData];

				if($scope.MetricMap.length > 0)
					$scope.parentChildMap = $scope.createparentChildMetricMap();
				else
				{
					$scope.metricData = {};
					$scope.parentChildMap = {};
					$scope.parentChildMap["0"] = [];
				}
			});
			callbackMethod();
  		});	
  	};

  	$scope.createparentChildMetricMap = function()
  	{
  		var parentChildMap = {};
  		$scope.metricData = {};
 
  		for(var i = 0; i < $scope.MetricMap.length; i++)
  		{
  			if(parentChildMap[$scope.MetricMap[i].parentID] == undefined)
  			{
  				parentChildMap[$scope.MetricMap[i].parentID] = [];
  			}
  			parentChildMap[$scope.MetricMap[i].parentID].push($scope.MetricMap[i].metricID);

  			var copiedFormula = jQuery.extend(true, angular.copy(metricObject.formula), angular.fromJson($scope.MetricMap[i].formula));

  			$scope.metricData[$scope.MetricMap[i].metricID] = $scope.MetricMap[i];
  			$scope.metricData[$scope.MetricMap[i].metricID].formula = copiedFormula;//angular.fromJson($scope.metricData[$scope.MetricMap[i].metricID].formula);
  		}
  		
  		return parentChildMap;
  	};

  	$scope.getAllMetricValueFromService = function(callbackMethod)
  	{
  		$(".loader").show();
  		if($scope.selectedCategoryID == 0 && $scope.selectedFrequencyID == 0 && $scope.selectedSchoolYear == 0)
  			return;
  		
  		var params = {"categoryID":$scope.selectedCategoryID + "", "frequencyID":$scope.selectedFrequencyID + "", "yearValue":$scope.selectedSchoolYear+""};
  
  		var paramData = angular.copy(kpiTrackerServiceObject);
		paramData.serviceName = "getMetricData";
		paramData.data = angular.toJson(params);

		$scope.sdk.secureRequest($scope.reqiureUrl, paramData, function(response)
		{
  			var currentMetricResponse = response.MdiCoreResp.currentmetricData;
  			var previousMetricResponse = response.MdiCoreResp.prevmetricData;

  		  	$scope.$apply(function()
  			{
  		  		$scope.initializeMetricValueFromService();
 
	  		  	if(!angular.isDefined(currentMetricResponse))
	  		  		angular.noop();
				else
				if(angular.isArray(currentMetricResponse))
					$scope.currentMetricMap = currentMetricResponse;
				else
					$scope.currentMetricMap = [currentMetricResponse];

	  		  	if(!angular.isDefined(previousMetricResponse))
	  		  		angular.noop();
				else
				if(angular.isArray(previousMetricResponse))
					$scope.previousMetricMap = previousMetricResponse;
				else
					$scope.previousMetricMap = [previousMetricResponse];

	  		  	$scope.createMapForMetricValues();
  			});
 
			callbackMethod();
  		});
  	};
  
  	$scope.initializeMetricValueFromService = function()
  	{
  		$scope.currentMetricMap = [];
  		$scope.previousMetricMap = [];
  		
  		$scope.currentMetricData = {};
  		$scope.previousMetricData = {};

  		for(var i = 0; i < $scope.MetricMap.length; i++)
  		{
  			$scope.currentMetricData[$scope.MetricMap[i].metricID] = angular.copy(metricValuesObject);
  			$scope.currentMetricData[$scope.MetricMap[i].metricID].metricID = {"metricID":$scope.MetricMap[i].metricID};
  			$scope.currentMetricData[$scope.MetricMap[i].metricID].spaceKey = $scope.userDetails.user.spaceKey;
  			$scope.currentMetricData[$scope.MetricMap[i].metricID].frequencyID = $scope.selectedFrequency;
  			$scope.currentMetricData[$scope.MetricMap[i].metricID].yearValue = $scope.selectedSchoolYear+"";

  			$scope.previousMetricData[$scope.MetricMap[i].metricID] = angular.copy(metricValuesObject);
  		}
  	};

  	$scope.createMapForMetricValues = function()
  	{
  		for(key in $scope.currentMetricMap)
  		{
  			var copiedData = jQuery.extend(true, angular.copy(metricValuesObject), $scope.currentMetricMap[key]);
  			$scope.currentMetricData[$scope.currentMetricMap[key]["metricID"].metricID] = copiedData;
  			$scope.currentMetricData[$scope.currentMetricMap[key]["metricID"].metricID].metricID = {"metricID":$scope.currentMetricMap[key].metricID.metricID};
  			$scope.currentMetricData[$scope.currentMetricMap[key]["metricID"].metricID].lastUpdatedString = $scope.currentMetricMap[0].lastUpdatedString;
  		}

  		for(key in $scope.previousMetricMap)
  		{
  			$scope.previousMetricData[$scope.previousMetricMap[key]["metricID"].metricID] = angular.copy($scope.previousMetricMap[key]);
  		}
  	};

  	$scope.downloadFile = function(fileObject, name)
  	{
  		if (isIE = /*@cc_on!@*/false || !!document.documentMode || /Edge\/12./i.test(navigator.userAgent))// If Internet Explorer
  		{
  			var contentType = fileObject.split(",")[0];
 
  			contentType = contentType || '';
  			var sliceSize = 512;
  			var b64Data = fileObject.split(",")[1];
  			b64Data = b64Data.replace(/^[^,]+,/, '');
  			b64Data = b64Data.replace(/\s/g, '');
  			var byteCharacters = window.atob(b64Data);
  			var byteArrays = [];

  			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
  			    var slice = byteCharacters.slice(offset, offset + sliceSize);

  			    var byteNumbers = new Array(slice.length);
  			    for (var i = 0; i < slice.length; i++) {
  			        byteNumbers[i] = slice.charCodeAt(i);
  			    }

  			    var byteArray = new Uint8Array(byteNumbers);

  			    byteArrays.push(byteArray);
  			}

  			var blob = new Blob(byteArrays, {type: contentType});
  			
  			if (window.saveAs) { window.saveAs(blob, name); }
  		    else 
  		    {
  		    	window.navigator.msSaveBlob(blob, name); 
  		    }
  		}
  		else if(isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0)// If Safari
  		{
  			 window.open(fileObject);  		
  		}
  		else// other browsers chrome, firefox, opera
  		{
  			var link = document.createElement('a');
  			link.setAttribute('id', 'anchor');
  			document.body.appendChild(link);
  			var anchorobj=document.getElementById('anchor');
  			anchorobj.href = fileObject;
  			anchorobj.download = name;
  			anchorobj.click();
  			anchorobj.remove();
  		}
  	};
  	
  	$scope.showAlert = function(msg, err, header)
  	{
  		$("#msgHeader").css( "background-color", $scope.themeDetails.headerBGColor);
  		if(err == "error")
  			$("#msgHeader").css( "background-color", "#cc0000");
  		
  		$('#MessageBox').modal({
  			show: true,
  		});
  		
		$("#modal-title-area").html("Instructions");
		if(header != null && header != undefined)
			$("#modal-title-area").html(header);
		
  		$("#modal-body-MessageBox").empty();
  		$("#modal-body-MessageBox").html(msg);
  	};
  	
  	$scope.noCallBackMethod = function()
  	{
  		
  	};
}]);

metricModule.directive('contenteditable', function () {
    return {
        restrict: 'A',
        require: '?ngModel',
        link: function (scope, element, attrs, ngModel) {
            if (!ngModel) 
            	return;

            ngModel.$render = function () {
                element.html(ngModel.$viewValue || '');
            };

            element.on('blur keyup change', function () {
                scope.$apply(readViewText);
            });

            function readViewText() {
                var html = element.html();
                if (attrs.stripBr && html == '<br>') {
                    html = '';
                }
                html = html.replace(/<(.|\n)*?>/g, "").replace(/&nbsp;/g," ");
                ngModel.$setViewValue(html);
            }
        }
    };
});

metricModule.directive('ckEditor', [function () {
    return {
    	require: '?ngModel',
        restrict: 'C',
        priority: 1,
        link: function(scope, elm, attr, ngModel) 
        {
            var ck = CKEDITOR.replace(elm[0]);

            if (!ngModel) return;

            ck.on('instanceReady', function() {
              ck.setData(ngModel.$viewValue);
            });

            function updateModel() 
            {
                scope.$apply(function() {
                	if ( ck.getData().length >=0)
                		ngModel.$setViewValue(ck.getData());
                });
            }

            ck.on('change', updateModel);
            ck.on('onLoad', updateModel);
            ck.on('key', updateModel);
            ck.on('pasteState', updateModel); 

            ngModel.$render = function(value) {
              ck.setData(ngModel.$viewValue);
            };
        }
    };
}]);

metricModule.directive("ngcontextmenu", function()
{
    return {
		restrict: 'EA',
		link : function ($scope, element, attributes) 
        {
			element[0].oncontextmenu = function(e)
			{
				e.preventDefault();
				e.stopPropagation();
				parentID = this.id.split("-")[1];

				$("#toolTipDiv").show(500);		
				$('#toolTipDiv').css(
				{
					"left":e.clientX + "px",
					"top":e.clientY-20 + "px"
				});

				$("#child_Metric_0").unbind( "click" );
				$("#child_Metric_0").click(function()
				{
					$scope.$apply(function()
					{
						$("#toolTipDiv").hide();
						$scope.createChildMetric(parentID);
					});
				});

				$("#_1").unbind( "click" );
				$("#_1").click(function()
				{
					$("#toolTipDiv").hide();
					$scope.deleteMetricFamily(parentID);
				});
			};
        }
    };
});

metricModule.filter('splitSchoolYear', function()
{
	return function(number)
	{
		return number + "/" + (number + 1).toString().substring(2);
	};
});

metricModule.directive("checkboxGroup", function() {
    return {
        restrict: "E",
        template: '<label ng-repeat = "option in columnDetails[key].options.split(\',\')">'+
							'<input type="checkbox" name = "{{key+\'-\'+metric.metricID}}" ng-value="convertIfNum(option,key)" ng-disabled = "!metric.formula[key].editable">{{option}}&nbsp;&nbsp;'+
						'</label>',
        link: function($scope, elem, attrs) 
        {
        	var checkboxname = attrs.checkboxname;

        	$scope.$watch('currentMetricData[metric.metricID][key]', function(newVal, oldVal)
        	{
	    		$("input:checkbox[name = '"+checkboxname+"']").each(function()
	    		{
	    			$(this).prop('checked', false);
	    		});

        		if(newVal == undefined)
        	    	newVal = "";
 
        	    var optionArray = newVal.split("~separate~");
 
        	    $.each(optionArray, function(index, optionValue)
        		{
                	$(elem).find("input[value = '"+optionValue+"']").prop('checked', true);
        		});
        	},false);
        }
    };
});

metricModule.directive("fileread", [function () 
{
	return {
		link: function ($scope, element, attributes) 
		{
			element.bind("change", function (event) 
			{
		      	var files = event.target.files;
		      	var file = files[0];

	           	if (files && file)
	           	{
	           		var name = file.name;
	           	   	var reader = new FileReader();
	               	reader.onload = function(readerEvt) 
	               	{
	               		var fileObj = readerEvt.target.result;

	               		var metricID = attributes.name;

	          	       	$scope.$apply(function()
	          	       	{
	          	       		$scope.currentMetricData[metricID]["fileName"] = name;
	          	       		$scope.currentMetricData[metricID]["fileContent"] = fileObj;
	          	       	});
	               	};
	                reader.readAsDataURL(file);                	
	            }
	        });
		}
	};
}]);

metricModule.directive('thousandSeparator', function(){
   return {
     require: 'ngModel',
     link: function(scope, element, attrs, modelCtrl) 
     {
    	 modelCtrl.$formatters.push(function (inputValue) 
    	 {
    		 if(!angular.isNumber(inputValue))
    			 return inputValue;

    		 number = (inputValue + '').replace(/[^0-9]+\-Ee.]/g, '');    		
    		 number = number.replace(/,/g ,"");

    		 s =  ('' + number).split('.');
    		 if (s[0].length > 3) 
    		 {
    			 s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, ",");
    		 }

    		 var transformedInput = s.join(".");

    		 return transformedInput;         
    	 });

    	 modelCtrl.$parsers.push(function(inputValue) 
    	 {
    		 return inputValue.replace(/,/g ,"");
    	 });
     }
   };
});

metricModule.directive('modal', function () {
	return {
		restrict: 'E',
		templateUrl: pathforpopHtml,
		//templateUrl: 'views/kpitracker/popUpTemplete.html',
		//templateUrl: 'popUpTemplete.html',
		replace:true,
		link: function postLink(scope, element, attrs) 
		{
			scope.title = attrs.title;
			scope.$watch(attrs.visible, function(value)
			{
				if(value == true)
					$(element).modal('show');
		        else
		        	$(element).modal('hide');
		    });
		},
	};
});

metricModule.directive("bizvizFileExplorer", function() {
	return {
		restrict: "EA",
		controller: "FileExplorerController",
		templateUrl: "../../views/kpitracker/FileExplorer.html"
	};
});

metricModule.filter('orderObjectBy', function()
{
	return function(input, attribute) 
	{
		var keys = [];
		for(var key in input)
		{
			if(input[key].exists == true)
				keys.push(key);
		}
		return keys.sort(function(a,b)
		{
	 		return input[a][attribute] - input[b][attribute];
	 	});
	};
});

function ajaxCall(ajaxObj, serviceId, callback, msgNo)
{
	document.getElementById("loaderDiv").style.display = "block";
	$.ajax(
	{
	    type: "POST",
	    url: serviceId, 
	    data: ajaxObj,
	    traditional : true,
	    crossDomain:true,
	    success:(function(response, status, headers, config)
	    {
	    	document.getElementById("loaderDiv").style.display = "none";
	    	for(var propName in response) 
	    	{
	    		if(response[propName].sucess == false &&  response[propName].errorMessage == "Invalid Token/Request")
		    	{
		    		$scope.showAlert("Session Expired. Please re-login.", "error");
		    		return;
		    	}
	    		break;
	    	}
	    	callback(response, msgNo);
	    }),
	    error: function(data,status)
	    {
	    	$scope.showAlert("Error  "+status);
	    }
	});
}
