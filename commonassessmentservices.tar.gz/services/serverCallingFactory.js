sisModule.factory('serverCall',['$rootScope' , function($rootScope) {
	
	var serviceInterface = {};
	
	//Generic function for save and update
  	serviceInterface.confirmationBox = function (boxContent, ajaxObj, servicename, callbackMethod) {
  		$('#approvelStatusConfirmation').modal({
  			backdrop: 'static',
  			show: true,
  		});
  		$("#modal-title-area").html("Confirmation");
  		$("#modal-body-approvalStatus").empty();
  		$("#modal-body-approvalStatus").html(boxContent);  		
  		$("#changeStatus").unbind( "click" );
  		
  		$("#changeStatus").on('click',function() {
  			$(".loader").show();
  	  		var paramData = angular.copy(assesmentServiceObject);
  			paramData.serviceName = servicename;
  			paramData.data = ajaxObj;
  			//console.log(paramData.data);
  			$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
  				callbackMethod(response);
  			});
  		});  		
  		$("#changeStatusCancel").unbind( "click" );
  		$("#changeStatusCancel").on('click',function() {
  			angular.noop();
  		});
  	};
  	serviceInterface.saveData=function(data,servicename,callbackMethod){
  		$(".loader").show();
  		var paramData=angular.copy(assesmentServiceObject);
  		paramData.serviceName=servicename;
  		paramData.data=data;
  		
  		$rootScope.sdk.secureRequest($rootScope.requireURL,paramData,function(response){
  			callbackMethod(response);
  		});
  	}
  	/*serviceInterface.getAllSchoolYears = function (data, servicename, callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
		paramData.serviceName = servicename;
		paramData.data = data;

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
		});
  	};
*/  	
    //Getting all Teacher details
  	serviceInterface.getAllTeacherList = function (data, servicename, callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
		paramData.serviceName = servicename;
		paramData.data = data;

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
		});
  	};
  	
    //Getting all Subect details
  	serviceInterface.getAllSubjectList = function (data, servicename, callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
		paramData.serviceName = servicename;
		paramData.data = data;

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
		});
  	};
  	
    //Getting all Grade details
  	serviceInterface.getAllGradeList = function (data, servicename, callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
		paramData.serviceName = servicename;
		paramData.data = data;

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
		});
  	};
  	
    //Getting all Class details
  	serviceInterface.getAllClassList = function (data, servicename, callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
		paramData.serviceName = servicename;
		paramData.data = data;

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
		});
  	};
  	
    //Getting all Question details
  	serviceInterface.getAllQuestionList = function (data, servicename, callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
		paramData.serviceName = servicename;
		paramData.data = data;

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
		});
  	};
  	
    //Getting all Sudent details
  	serviceInterface.getAllStudentList = function (data, servicename, callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
		paramData.serviceName = servicename;
		paramData.data = data;

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
		});
  	};
  	
    //Getting all Question details
  	serviceInterface.getQuestionByStandard = function (data, servicename, callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
		paramData.serviceName = servicename;
		paramData.data = data;

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
		});
  	};
  	
  	
    //Getting all Student details
  	serviceInterface.getAllStudentwithScoreValue = function(data,callbackMethod) {
		$(".loader").show();
  		var paramData = angular.copy(assesmentServiceObject);
  		paramData.data = data;
		paramData.serviceName = "getStudentsScoreByFilters";

		$rootScope.sdk.secureRequest($rootScope.requireURL, paramData, function(response) {
			callbackMethod(response);
  		});
  	};
  	
	
 	return serviceInterface;
}]);