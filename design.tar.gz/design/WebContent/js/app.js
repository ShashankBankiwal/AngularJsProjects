
var app=angular.module('design',['ngMaterial','ngRoute']);
app.controller('myController',function($scope,$http){
	$http.get("data/data.json").then(function(response){
		$scope.buttons=response.data;
	});	
});
