angular.
	module("ngClassifieds",[])
	.config(function($mdThemingProvider){
		$mdThemingProvider.theme('default')
			.primaryPalette('orange');
	})
	.directive("helloWorld",function(){
		return {
			template:"<h1>Hello, world</h1>"
		}
	});