(function(){
	
	"use strict";
	
	angular.module("MetricData")
		.factory("frequencyFactory",function($http,$rootScope, $q, authFactory,$location){
			function getFrequency(){
				return $http.get('dataset/data.json');
			}
			return {
				getFrequency: getFrequency
			}
		})
})();