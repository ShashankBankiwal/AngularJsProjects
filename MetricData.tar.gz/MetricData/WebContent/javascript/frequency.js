var app=angular.module('MetricData');
app.controller("frequencyCtrl",function($routeParams,$scope,/*frequencyfactory,*/$http){

	$scope.intervalName="";
	$scope.frequencyName="";
	$scope.date1="";
	$scope.date2="";
	$scope.startDate="";
	$scope.endDate="";
	$scope.orderValue="";
	$scope.frequencydata={};
	$scope.editIndex=-1;
	$scope.currentFrequencyInstance = angular.copy(frequencyIntervalObject);
	
	/*frequencyfactory.getFrequency()then(function(frequency){
		$scope.frequencydata = frequency.data;
	})*/
	
	$scope.getAllFrequencyData = function(response)
	{
		if(response != undefined)
		{
			if(response.metric_Frequency_IntervalResponse.sucess == true)
				$scope.showAlert(response.metric_Frequency_IntervalResponse.message,"noError");
			else
				$scope.showAlert(response.metric_Frequency_IntervalResponse.message,"error");
		}
		$scope.getAllFrequencyFromService($scope.clearFrequencyData);
	};
	
	$scope.createAccount=function(frequency){
		if($scope.intervalName!=null){
			if($scope.editIndex==-1){
				var freq= angular.copy(frequencyObject);
				freq["spacekey"]= spaceKey;
				freq["frequencyName"]= $scope.frequencyName;
				freq["orderValue"]= $scope.orderValue;
				freq["properties"]=JSON.stringify({"startPeriod":$scope.startDate,"endPeriod":$scope.endDate});
				$scope.currentFrequencyInstance["metric_Frequency"].splice(0,0,freq);
			}
			else{
				var obj1=$scope.currentFrequencyInstance.metric_Frequency[$scope.editIndex];
				obj1.frequencyName= $scope.frequencyName;
				obj1.properties=JSON.stringify({"startPeriod":$scope.startDate,"endPeriod":$scope.endDate});
				$scope.currentFrequencyInstance["metric_Frequency"][$scope.editIndex] = obj1;
			}
			$scope.frequencyName="";
			$scope.startDate="";
			$scope.endDate="";
			$scope.editIndex=-1;
		}
		else return;
	}
	
	$scope.clearData=function(){
		$scope.intervalName="";
		$scope.frequencyName="";
		$scope.date1="";
		$scope.date2="";
	}
	
	/*$scope.saveData=function(frequency){
		if(frequency){
			$scope.frequencydata.push(frequency);
			$scope.clearData();
			alert("Your data has been saved successfully!");
		}
		//calling of a service to save data
	}*/
	
	$scope.saveFrequencyInterval = function()
	{
		//$("small").remove(".validators");
		if($scope.hasError())
			return;

		var ajaxObj = {};
		ajaxObj["spaceKey"] = spaceKey;
		ajaxObj["token"] = authToken;

		$scope.currentFrequencyInstance["spaceKey"] = spaceKey;
	    ajaxObj["metric_Frequency_Interval"] = angular.toJson($scope.currentFrequencyInstance);
	    $scope.confirmationBox("This will save frequency Interval", ajaxObj, "SAVEFREQUENCYINTERVAL", $scope.getAllFrequencyData, "", "");
	};
});