var app=angular.module('MetricData');
/*app.config('formlyConfigProvider',function(formlyConfigProvider) {
    // set templates here
    formlyConfigProvider.setType({
        name: 'ckeditor',
        templateUrl: 'ckeditor.html'
    });
});
*/
app.controller('formCtrl',function($routeParams,$scope){
	$scope.months=[
	               "January", "February", "March", "April", "May"," June", " July ", "August", " September", "October ", "November", "December"
	               ]
	/*var ckeditorField = function (key) {
    	return [{
        	className: "col-md-12",
        		"type": "ckeditor",
        		"key": key
    	}];
	};
	$scope.field_name = ckeditorField("my_model_key");*/
});