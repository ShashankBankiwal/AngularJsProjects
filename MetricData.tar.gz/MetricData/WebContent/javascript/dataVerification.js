var app=angular.module('MetricData');
app.controller('dataVerificationCtrl',function($routeParams,$scope){
	/*		var self=this;
			
			self.personalinfo=$routeParams.personalinfo;*/
		
	});