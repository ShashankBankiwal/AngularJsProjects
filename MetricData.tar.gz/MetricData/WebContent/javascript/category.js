var app=angular.module('MetricData');
app.controller('categoryCtrl',function($routeParams,$scope){
	/*		var self=this;
			
			self.personalinfo=$routeParams.personalinfo;*/
		
	});