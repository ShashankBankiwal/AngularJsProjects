var app = angular.module('MetricData', ['ngMaterial','ngRoute']);
	 app.config(function ($mdThemingProvider,$mdIconProvider) {
	  $mdThemingProvider
	    .theme('white')
	    .primaryPalette('indigo')
	    .accentPalette('pink')
	    .warnPalette('red')
	    .backgroundPalette('blue-grey');
	})
	app.controller("myController",function($scope, $mdSidenav){
		$scope.openLeftMenu=function(){
			$mdSidenav('left').toggle();
		}
		$scope.closeLeftMenu=function(){
			$mdSidenav('left').close();
		}
		/*$scope.opensideNav1=function(){
			$mdSidenav('right1').toggle();
		}
		$scope.closesideNav1=function(){
			$mdSidenav('right1').close();
		}
		$scope.opensideNav2=function(){
			$mdSidenav('right2').toggle();
		}
		$scope.closesideNav2=function(){
			$mdSidenav('right2').close();
		}
		$scope.opensideNav3=function(){
			$mdSidenav('right3').toggle();
		}
		$scope.closesideNav3=function(){
			$mdSidenav('right3').close();
		}
		$scope.opensideNav4=function(){
			$mdSidenav('right4').toggle();
		}
		$scope.closesideNav4=function(){
			$mdSidenav('right4').close();
		}
		$scope.details=detailsFactory.getDetails().then(function(details){
			$scope.details=details.data;
		});*/
		
	})
	app.config(function config($routeProvider){
		
		$routeProvider
		.when('/home',{
			templateUrl:'html/frequency.html',
			controller:'frequencyCtrl',
		})
		.when('/frequency',{
			templateUrl:'html/frequency.html',
			controller:'frequencyCtrl'
		}).
		when('/form',{
			templateUrl:'html/form.html',
			controller:'formCtrl'
		}).
		when('/category',{
			templateUrl:'html/category.html',
			controller:'categoryCtrl'
		}).
		when('/metric',{
			templateUrl:'html/metric.html',
			controller:'metricCtrl'
		}).
		when('/formPreview',{
			templateUrl:'html/formPreview.html',
			controller:'formPreviewCtrl'
		}).
		when('/dataVerification',{
			templateUrl:'html/dataVerification.html',
			controller:'dataVerificationCtrl'
		}).
		otherwise('/home');
	})
	/*app.controller('frequencyCtrl',function($routeParams){
		var self=this;
		self.home=$routeParams.home;
		self.home=detailsFactory.getDetails().then(function(details){
			$scope.details=details.data;
	})*/
	/*app.controller('frequencyCtrl',function($routeParams){
		var self=this;
		self.personalinfo=$routeParams.personalinfo;
	})*/
	/*app.controller('formCtrl',function($routeParams){
		var self=this;
		self.subscriptions=$routeParams.subscriptions;
	})
	app.controller('categoryCtrl',function($routeParams){
		var self=this;
		self.security=$routeParams.security;
	})
	app.controller('metricCtrl',function($routeParams){
		var self=this;
		self.permissions=$routeParams.permissions;
	})
	app.controller('formPreviewCtrl',function($routeParams){
		var self=this;
		self.install=$routeParams.install;
	})
	app.controller('dataVerificationCtrl',function($routeParams){
		var self=this;
		self.verify=$routeParams.verify;
	})*/
/*
var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "main.htm",
    })
    .when("/london", {
        templateUrl : "london.htm",
        controller : "londonCtrl"
    })
    .when("/paris", {
        templateUrl : "paris.htm",
        controller : "parisCtrl"
    });
});
app.controller("londonCtrl", function ($scope) {
    $scope.msg = "I love London";
});
app.controller("parisCtrl", function ($scope) {
    $scope.msg = "I love Paris";
});
*/



	/*.component('home-icon',{
		templateUrl:"home/details.html",
		controller: function($http){
			var self=this;
			$http.get('json/details.json').then(function(response){
				self.details=details.data;
			});
		}
	});*/