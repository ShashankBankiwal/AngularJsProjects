var app=angular.module('MetricData');
app.controller('metricCtrl',function($routeParams,$scope){
	/*		var self=this;
			
			self.personalinfo=$routeParams.personalinfo;*/
		
	});